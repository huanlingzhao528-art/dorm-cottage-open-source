"""Cat Dorm LAN server. Python 3.9+, standard library only."""
import argparse
import json
import secrets
import sqlite3
import threading
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LOCK = threading.RLock()
DB = None


def init_db(path):
    global DB
    DB = sqlite3.connect(path, check_same_thread=False)
    DB.row_factory = sqlite3.Row
    DB.executescript('''
    CREATE TABLE IF NOT EXISTS rooms(code TEXT PRIMARY KEY, created REAL);
    CREATE TABLE IF NOT EXISTS cats(
      id TEXT PRIMARY KEY, room TEXT, slot INTEGER, token TEXT UNIQUE,
      name TEXT, state TEXT DEFAULT 'awake', reason TEXT DEFAULT '',
      start TEXT DEFAULT '', end TEXT DEFAULT '', updated REAL,
      UNIQUE(room, slot));
    CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT, sender TEXT, recipient TEXT, body TEXT, created REAL);
    CREATE TABLE IF NOT EXISTS events(
      id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT, cat TEXT,
      name TEXT, reason TEXT, created REAL);
    ''')
    room_columns = {r[1] for r in DB.execute("PRAGMA table_info(rooms)")}
    if "name" not in room_columns:
        DB.execute("ALTER TABLE rooms ADD COLUMN name TEXT DEFAULT '8-313'")
    columns = {r[1] for r in DB.execute("PRAGMA table_info(cats)")}
    if "activity" not in columns:
        DB.execute("ALTER TABLE cats ADD COLUMN activity TEXT DEFAULT 'awake'")
    if "appearance" not in columns:
        DB.execute("ALTER TABLE cats ADD COLUMN appearance INTEGER DEFAULT 0")
        DB.execute("UPDATE cats SET appearance=slot")
    if "bedding" not in columns:
        DB.execute("ALTER TABLE cats ADD COLUMN bedding TEXT DEFAULT 'original'")
    if "style" not in columns:
        DB.execute("ALTER TABLE cats ADD COLUMN style TEXT DEFAULT 'original'")
    message_columns = {r[1] for r in DB.execute("PRAGMA table_info(messages)")}
    if "deleted" not in message_columns:
        DB.execute("ALTER TABLE messages ADD COLUMN deleted INTEGER DEFAULT 0")
    DB.execute("UPDATE cats SET end='' WHERE end!=''")
    DB.commit()


def parse_date(value):
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            raise ValueError()
        return parsed.timestamp()
    except (ValueError, TypeError):
        raise ValueError('时间格式无效，请使用带时区的 ISO 时间')


def evolve(room):
    now = time.time()
    for cat in DB.execute('SELECT * FROM cats WHERE room=?', (room,)).fetchall():
        start = parse_date(cat['start'])
        if cat['state'] == 'scheduled' and start and start <= now:
            DB.execute("UPDATE cats SET state='sleeping', updated=? WHERE id=?", (now, cat['id']))
            event(room, cat['id'], cat['name'], cat['reason'])


def event(room, cat, name, reason):
    DB.execute('INSERT INTO events(room,cat,name,reason,created) VALUES(?,?,?,?,?)', (room, cat, name, reason, time.time()))


def snapshot(room):
    evolve(room)
    cats = [dict(row) for row in DB.execute('SELECT id,slot,appearance,bedding,style,name,state,activity,reason,start,end,updated FROM cats WHERE room=? ORDER BY slot', (room,))]
    events = [dict(row) for row in DB.execute('SELECT id,cat,name,reason,created FROM events WHERE room=? ORDER BY id DESC LIMIT 100', (room,))][::-1]
    day = datetime.fromtimestamp(time.time(), ZoneInfo('Asia/Shanghai')).replace(hour=0, minute=0, second=0, microsecond=0)
    messages = [dict(row) for row in DB.execute('SELECT id,sender,recipient,body,created FROM messages WHERE deleted=0 AND room=? AND created>=? AND created<? ORDER BY id DESC LIMIT 50', (room, day.timestamp(), (day + timedelta(days=1)).timestamp()))]
    return {'room': room, 'roomName': DB.execute('SELECT name FROM rooms WHERE code=?', (room,)).fetchone()[0], 'cats': cats, 'events': events, 'messages': messages, 'serverTime': time.time()}


def api(path, data, token=''):
    with LOCK, DB:
        if path == '/api/preview':
            room = str(data.get('room', '')).strip()
            if not DB.execute('SELECT 1 FROM rooms WHERE code=?', (room,)).fetchone():
                raise ValueError('没有找到这个宿舍，请检查邀请码')
            return {'occupied': [r[0] for r in DB.execute('SELECT slot FROM cats WHERE room=?', (room,))]}
        if path in ('/api/create', '/api/join'):
            name = str(data.get('name', '')).strip()[:16]
            if not name:
                raise ValueError('请给你的小猫取个名字')
            if path.endswith('create'):
                while True:
                    room = str(secrets.randbelow(900000) + 100000)
                    if not DB.execute('SELECT 1 FROM rooms WHERE code=?', (room,)).fetchone():
                        break
                room_name = str(data.get('roomName', '8-313')).strip()[:24]
                if not room_name:
                    raise ValueError('请填写宿舍名称')
                DB.execute('INSERT INTO rooms(code,created,name) VALUES(?,?,?)', (room, time.time(), room_name))
            else:
                room = str(data.get('room', '')).strip()
                if not DB.execute('SELECT 1 FROM rooms WHERE code=?', (room,)).fetchone():
                    raise ValueError('没有找到这个宿舍，请检查邀请码')
            slots = {r[0] for r in DB.execute('SELECT slot FROM cats WHERE room=?', (room,))}
            if len(slots) >= 4:
                raise ValueError('宿舍已经住满四只猫啦')
            slot = data.get('slot', next(i for i in range(4) if i not in slots))
            if type(slot) is not int or slot not in range(4):
                raise ValueError('请选择有效的床位')
            if slot in slots:
                raise ValueError('这个床位已有人入住，请换一个')
            appearance = data.get('appearance', slot)
            if type(appearance) is not int or appearance not in range(8):
                raise ValueError('请选择一只小猫')
            cat_id, key = secrets.token_hex(12), secrets.token_urlsafe(32)
            DB.execute('INSERT INTO cats(id,room,slot,appearance,token,name,updated) VALUES(?,?,?,?,?,?,?)', (cat_id, room, slot, appearance, key, name, time.time()))
            return {'token': key, 'id': cat_id, **snapshot(room)}
        cat = DB.execute('SELECT * FROM cats WHERE token=?', (token,)).fetchone()
        if cat is None:
            raise PermissionError('身份已失效，请重新进入宿舍')
        room = cat['room']
        evolve(room)
        cat = DB.execute('SELECT * FROM cats WHERE id=?', (cat['id'],)).fetchone()
        if path == '/api/leave':
            DB.execute('DELETE FROM cats WHERE id=?', (cat['id'],))
            return {'left': True}
        if path == '/api/update':
            name = str(data.get('name', cat['name'])).strip()[:16]
            reason = str(data.get('reason', cat['reason'])).strip()[:120]
            state = data.get('state', cat['state'])
            appearance = data.get('appearance', cat['appearance'])
            bedding = data.get('bedding', cat['bedding'])
            style = data.get('style', cat['style'])
            if style not in ('original', 'plain', 'gingham', 'stripes', 'stars', 'paws'):
                raise ValueError('请选择有效的床单样式')
            if type(appearance) is not int or appearance not in range(8):
                raise ValueError('请选择有效的小猫形象')
            if bedding not in ('original', 'cream', 'peach', 'blue', 'mint', 'lavender'):
                raise ValueError('请选择有效的床单颜色')
            activity = data.get('activity', cat['activity'])
            if activity not in ('awake', 'study', 'music', 'reading', 'gaming', 'away'):
                raise ValueError('请选择有效的日常状态')
            start = data.get('start', cat['start'])
            end = ''
            if not name or state not in ('awake', 'sleeping', 'scheduled'):
                raise ValueError('名字或状态无效')
            if state != 'awake':
                if state == 'scheduled':
                    start_ts = parse_date(start)
                    if start_ts is None or start_ts <= time.time():
                        raise ValueError('预约时间需要晚于现在')
                elif cat['state'] != 'sleeping':
                    start = datetime.now().astimezone().isoformat()
            else:
                start, end, reason = '', '', ''
            DB.execute('UPDATE cats SET name=?,state=?,activity=?,appearance=?,bedding=?,style=?,reason=?,start=?,end=?,updated=? WHERE id=?', (name, state, activity, appearance, bedding, style, reason, start, end, time.time(), cat['id']))
            if state == 'sleeping' and cat['state'] != 'sleeping':
                event(room, cat['id'], name, reason)
        elif path == '/api/delete-message':
            note_id = data.get('id')
            if type(note_id) is not int:
                raise ValueError('纸条编号无效')
            note = DB.execute('SELECT sender FROM messages WHERE id=? AND room=?', (note_id, room)).fetchone()
            if note is None or note['sender'] != cat['id']:
                raise PermissionError('只能删除自己写的纸条')
            DB.execute('UPDATE messages SET deleted=1 WHERE id=?', (note_id,))
        elif path == '/api/message':
            body = str(data.get('body', '')).strip()
            recipient = str(data.get('recipient', 'all'))
            if not body or len(body) > 200:
                raise ValueError('留言需为 1—200 字')
            if recipient != 'all' and not DB.execute('SELECT 1 FROM cats WHERE id=? AND room=?', (recipient, room)).fetchone():
                raise ValueError('这位室友不在你的宿舍')
            DB.execute('INSERT INTO messages(room,sender,recipient,body,created) VALUES(?,?,?,?,?)', (room, cat['id'], recipient, body, time.time()))
        elif path != '/api/state':
            raise ValueError('接口不存在')
        return snapshot(room)


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size < 1 or size > 8192:
                raise ValueError('请求大小无效')
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict):
                raise ValueError('请求格式无效')
            result = api(self.path, data, self.headers.get('Authorization', '').removeprefix('Bearer '))
            self.reply(200, result)
        except PermissionError as exc:
            self.reply(401, {'error': str(exc)})
        except (ValueError, TypeError, OverflowError) as exc:
            self.reply(400, {'error': str(exc)})
        except Exception:
            self.reply(500, {'error': '服务暂时不可用，请稍后重试'})

    def reply(self, code, data):
        raw = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        files = {'/': ROOT / 'preview/index.html', '/concept.png': ROOT / 'app/assets/concept.png', '/room.png': ROOT / 'app/assets/room.png', '/day.png': ROOT / 'app/assets/day.png', '/closed.png': ROOT / 'app/assets/closed.png', '/cats.png': ROOT / 'app/assets/cats.png', '/activities.png': ROOT / 'app/assets/activities.png', '/awake.png': ROOT / 'app/assets/awake.png', '/extra.png': ROOT / 'app/assets/extra.png'}
        path = files.get(self.path)
        if path is None or not path.exists():
            self.send_error(404)
            return
        body = path.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', 'image/png' if path.suffix == '.png' else 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass  # Tokens and request bodies are never logged.


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--db', default=str(Path(__file__).with_name('dorm.sqlite3')))
    args = parser.parse_args()
    init_db(args.db)
    print(f'宿舍小屋：http://127.0.0.1:{args.port} （手机请换为电脑的局域网 IP）', flush=True)
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()
