import unittest
from datetime import datetime,timedelta,timezone
from unittest.mock import patch
from zoneinfo import ZoneInfo
import server

def future(hours=8):
    return (datetime.now(timezone.utc)+timedelta(hours=hours)).isoformat()

class DormTest(unittest.TestCase):
    def setUp(self):
        server.init_db(':memory:')
        self.a=server.api('/api/create',{'name':'小橘','appearance':0,'slot':0})
        self.b=server.api('/api/join',{'name':'小白','appearance':1,'slot':1,'room':self.a['room']})
    def tearDown(self):server.DB.close()
    def test_capacity_and_occupied_bed(self):
        with self.assertRaises(ValueError):server.api('/api/join',{'name':'猫','room':self.a['room'],'slot':0})
        for slot in [2,3]:server.api('/api/join',{'name':'猫','room':self.a['room'],'slot':slot,'appearance':0})
        with self.assertRaises(ValueError):server.api('/api/join',{'name':'猫','room':self.a['room']})
    def test_own_state_and_event_deduplication(self):
        result=server.api('/api/update',{'state':'sleeping','reason':'太累了','id':self.b['id']},self.a['token'])
        self.assertEqual(result['cats'][0]['state'],'sleeping')
        self.assertEqual(result['cats'][1]['state'],'awake')
        self.assertEqual(len(result['events']),1)
        result=server.api('/api/update',{'name':'猫的新名字','reason':'身体不舒服'},self.a['token'])
        self.assertEqual(len(result['events']),1)
        self.assertEqual(result['cats'][0]['name'],'猫的新名字')
    def test_schedule_and_manual_waking(self):
        server.api('/api/update',{'state':'scheduled','start':future(1)},self.a['token'])
        now=server.time.time()
        with patch.object(server.time,'time',return_value=now+3700):
            result=server.api('/api/state',{},self.b['token'])
            self.assertEqual(result['cats'][0]['state'],'sleeping')
            self.assertEqual(len(result['events']),1)
        with patch.object(server.time,'time',return_value=now+86400):
            self.assertEqual(server.api('/api/state',{},self.a['token'])['cats'][0]['state'],'sleeping')
        result=server.api('/api/update',{'state':'awake'},self.a['token'])
        self.assertEqual(result['cats'][0]['state'],'awake')
    def test_auth_and_invalid_schedule(self):
        with self.assertRaises(PermissionError):server.api('/api/state',{},'wrong')
        for start in ['nonsense',future(-1),'']:
            with self.assertRaises(ValueError):server.api('/api/update',{'state':'scheduled','start':start},self.a['token'])
    def test_activities_preserve_schedule(self):
        for activity in ['study','music','reading','gaming','away','awake']:
            result=server.api('/api/update',{'activity':activity},self.a['token'])
            self.assertEqual(result['cats'][0]['activity'],activity)
            self.assertEqual(len(result['events']),0)
        server.api('/api/update',{'state':'scheduled','start':future(1)},self.a['token'])
        self.assertEqual(server.api('/api/update',{'activity':'music'},self.a['token'])['cats'][0]['state'],'scheduled')
    def test_select_activity_ends_sleep(self):
        server.api('/api/update',{'state':'sleeping'},self.a['token'])
        result=server.api('/api/update',{'state':'awake','activity':'reading'},self.a['token'])
        self.assertEqual(result['cats'][0]['state'],'awake')
        self.assertEqual(result['cats'][0]['activity'],'reading')
    def test_messages_independent_and_room_bound(self):
        server.api('/api/update',{'activity':'reading'},self.a['token'])
        result=server.api('/api/message',{'body':'明早做志愿，我会轻声出门','recipient':self.b['id']},self.a['token'])
        self.assertEqual(result['cats'][0]['activity'],'reading')
        self.assertEqual(len(result['events']),0)
        self.assertEqual(len(server.api('/api/state',{},self.b['token'])['messages']),1)
        for body in ['', 'a'*201]:
            with self.assertRaises(ValueError):server.api('/api/message',{'body':body},self.a['token'])
        with self.assertRaises(ValueError):server.api('/api/message',{'body':'test','recipient':'another-room'},self.a['token'])
    def test_messages_expire_at_beijing_midnight(self):
        start=datetime(2026,11,22,23,59,tzinfo=ZoneInfo('Asia/Shanghai')).timestamp()
        with patch.object(server.time,'time',return_value=start):
            result=server.api('/api/message',{'body':'今天的纸条'},self.a['token'])
            self.assertEqual(len(result['messages']),1)
        with patch.object(server.time,'time',return_value=start+61):
            self.assertEqual(len(server.api('/api/state',{},self.a['token'])['messages']),0)
    def test_appearance_switch_bedding_and_slot(self):
        joined=server.api('/api/join',{'name':'同款猫','room':self.a['room'],'slot':3,'appearance':0})
        self.assertEqual(joined['cats'][-1]['slot'],3)
        self.assertEqual(joined['cats'][-1]['appearance'],0)
        for appearance in range(8):
            result=server.api('/api/update',{'appearance':appearance,'bedding':'mint','slot':2},self.a['token'])
            self.assertEqual(result['cats'][0]['appearance'],appearance)
            self.assertEqual(result['cats'][0]['slot'],0)
            self.assertEqual(result['cats'][0]['bedding'],'mint')
        for values in [{'appearance':8},{'appearance':True},{'bedding':'unknown'}]:
            with self.assertRaises(ValueError):server.api('/api/update',values,self.a['token'])
    def test_delete_only_own_note(self):
        result=server.api('/api/message',{'body':'准备删除的测试纸条'},self.a['token'])
        note_id=result['messages'][0]['id']
        with self.assertRaises(PermissionError):server.api('/api/delete-message',{'id':note_id},self.b['token'])
        result=server.api('/api/delete-message',{'id':note_id},self.a['token'])
        self.assertEqual(result['messages'],[])
    def test_bedding_styles_do_not_move_cat(self):
        for style in ['original','plain','gingham','stripes','stars','paws']:
            result=server.api('/api/update',{'style':style,'bedding':'blue'},self.a['token'])
            self.assertEqual(result['cats'][0]['slot'],0)
            self.assertEqual(result['cats'][0]['style'],style)
        with self.assertRaises(ValueError):server.api('/api/update',{'style':'invalid'},self.a['token'])
    def test_room_and_token_privacy(self):
        self.assertEqual(self.a['roomName'],'8-313')
        self.assertNotIn('token',self.a['cats'][0])
        self.assertEqual(server.api('/api/preview',{'room':self.a['room']})['occupied'],[0,1])

if __name__=='__main__':unittest.main()
