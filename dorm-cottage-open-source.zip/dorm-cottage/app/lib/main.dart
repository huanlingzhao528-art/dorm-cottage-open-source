import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const CatDorm());
class CatDorm extends StatelessWidget {
  const CatDorm({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: '宿舍小屋', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xffb58b65)),
      scaffoldBackgroundColor: const Color(0xfff8f3eb),
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(16))))),
    home: const DormPage());
}
class DormPage extends StatefulWidget {
  const DormPage({super.key});
  @override State<DormPage> createState() => _DormPageState();
}
class _DormPageState extends State<DormPage> with WidgetsBindingObserver {
  final server = TextEditingController(text: 'http://192.168.1.100:8765');
  final name = TextEditingController();
  final room = TextEditingController();
  final reason = TextEditingController();
  final message = TextEditingController();
  String recipient = 'all';
  int selectedAppearance = 0, selectedBed = 0, page = 0;
  final bedNames=const ['左上铺','左下铺','右上铺','右下铺'];
  final linenColors=const {'original':Color(0xffe9d8bf),'cream':Color(0xfff3d5a8),'peach':Color(0xfff2a89a),'blue':Color(0xff99bed5),'mint':Color(0xffa1c6ad),'lavender':Color(0xffb2a2ce)};
  final styleNames=const {'original':'原样','plain':'纯色','gingham':'格纹','stripes':'条纹','stars':'星星','paws':'猫爪'};
  String get roomMood {final sleeping=cats.where((c)=>c['state']=='sleeping').length;return sleeping==0?'☀️ 大家都醒着，自在活动吧':sleeping==cats.length?'💤 小屋休息中，让好梦继续':'🌙 有室友在休息，轻声一点';}
  final linenNames=const {'original':'原样','cream':'奶油','peach':'蜜桃','blue':'雾蓝','mint':'薄荷','lavender':'薰衣草'};
  List<int> occupied = [];
  final catNames = const ['小橘','小白','小灰','小墨','三花','暹罗','奶油','小棕'];
  bool scheduledMode = false;
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  SharedPreferences? prefs;
  Map<String, dynamic>? data;
  String token = '', catId = '', error = '', notice = '';
  int? lastEvent, lastMessage;
  Timer? timer;
  bool busy = false, online = false;
  DateTime start = DateTime.now().add(const Duration(hours: 1));
  List<dynamic> get cats => data?['cats'] as List<dynamic>? ?? [];
  Map<String,dynamic>? get me {
    for (final cat in cats) { if (cat['id'] == catId) return Map<String,dynamic>.from(cat); }
    return null;
  }
  @override void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); restore(); }
  Future<void> restore() async {
    prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    server.text = prefs!.getString('server') ?? server.text;
    token = prefs!.getString('token') ?? '';
    catId = prefs!.getString('catId') ?? '';
    if (token.isNotEmpty) await refresh(loadFields: true);
    timer = Timer.periodic(const Duration(seconds: 3), (_) { if (!busy && token.isNotEmpty) refresh(); });
  }
  @override void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && token.isNotEmpty) refresh();
  }
  Future<Map<String,dynamic>> api(String action, Map<String,dynamic> body) async {
    final base = server.text.trim().replaceAll(RegExp(r'/+$'), '');
    final uri = Uri.tryParse(base);
    if (uri == null || !['http','https'].contains(uri.scheme) || uri.host.isEmpty) throw Exception('请填写有效的服务器地址');
    final req = await client.postUrl(Uri.parse('$base/api/$action')).timeout(const Duration(seconds: 8));
    req.headers.contentType = ContentType.json;
    req.headers.set('Authorization', 'Bearer $token');
    req.write(jsonEncode(body));
    final response = await req.close().timeout(const Duration(seconds: 8));
    final text = await response.transform(utf8.decoder).join().timeout(const Duration(seconds: 8));
    final value = jsonDecode(text) as Map<String,dynamic>;
    if (response.statusCode != 200) throw Exception(value['error'] ?? '请求失败');
    return value;
  }
  void apply(Map<String,dynamic> next, {bool loadFields = false}) {
    if (!mounted) return;
    bool shouldVibrate=false;
    setState(() {
      data = next; online = true; error = '';
      final events = next['events'] as List<dynamic>;
      if (lastEvent != null && me?['state'] != 'sleeping') {
        for (final e in events) {
          if ((e['id'] as int) > lastEvent! && e['cat'] != catId && DateTime.now().millisecondsSinceEpoch/1000 - (e['created'] as num) < 120) {
            shouldVibrate=true;
            notice = '${e['name']} 准备休息了。${e['reason'] == '' ? '请大家轻声一点～' : e['reason']}';
          }
        }
      }
      lastEvent = events.isEmpty ? 0 : events.last['id'] as int;
      final notes=next['messages'] as List<dynamic>? ?? [];
      if(lastMessage!=null&&me?['state']!='sleeping'&&notes.any((m)=>(m['id'] as int)>lastMessage!&&m['sender']!=catId&&(m['recipient']=='all'||m['recipient']==catId)))shouldVibrate=true;
      lastMessage=notes.isEmpty?0:notes.map((m)=>m['id'] as int).reduce((a,b)=>a>b?a:b);
      if (me?['state'] == 'sleeping') notice = '';
      if (loadFields && me != null) {
        name.text = me!['name']; reason.text = me!['reason']; scheduledMode = me!['state']=='scheduled';
        start = DateTime.tryParse(me!['start'])?.toLocal() ?? start;
      }
    });
    if(shouldVibrate) HapticFeedback.lightImpact();
  }
  void failed(Object e) { if (mounted) setState(() { error = e.toString().replaceFirst('Exception: ', ''); online = false; }); }
  Future<void> refresh({bool loadFields = false}) async {
    try { apply(await api('state', {}), loadFields: loadFields); } catch(e) { failed(e); }
  }
  Future<void> checkRoom() async {
    final code=room.text.trim();if(code.length!=6){setState(()=>occupied=[]);return;}
    try{final result=await api('preview',{'room':code});if(!mounted||room.text.trim()!=code)return;setState((){occupied=List<int>.from(result['occupied']);if(occupied.contains(selectedBed)){selectedBed=[0,1,2,3].firstWhere((i)=>!occupied.contains(i),orElse:()=>0);}});}catch(e){failed(e);}
  }
  Future<void> enter(bool create) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final next = await api(create ? 'create' : 'join', {'name': name.text, 'room': room.text.trim(), 'appearance': selectedAppearance, 'slot': selectedBed});
      token = next['token']; catId = next['id']; lastEvent = null;
      prefs ??= await SharedPreferences.getInstance();
      await prefs!.setString('server', server.text.trim());
      await prefs!.setString('token', token); await prefs!.setString('catId', catId);
      apply(next, loadFields: true);
    } catch(e) { failed(e); } finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> save(String? state) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final body = <String,dynamic>{'name': name.text};
      if (state != null) body.addAll({'state': state, 'reason': reason.text,
        'start': state == 'scheduled' ? start.toUtc().toIso8601String() : (me?['start'] ?? ''),
        'end': ''});
      apply(await api('update', body), loadFields: true);
    } catch(e) { failed(e); } finally { if (mounted) setState(() => busy = false); }
  }
  Future<bool> sendMessage() async {
    if(busy)return false;if(message.text.trim().isEmpty){setState(()=>error='先写一句想和室友说的话吧');return false;}
    setState(()=>busy=true);
    try{apply(await api('message',{'body':message.text.trim(),'recipient':recipient}));message.clear();if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('纸条贴好啦')));return true;}catch(e){failed(e);return false;}finally{if(mounted)setState(()=>busy=false);}
  }
  String format(DateTime t) => '${t.month}月${t.day}日 ${t.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}';
  Future<void> choose() async {
    final initial = start;
    final now = DateTime.now();
    final date = await showDatePicker(context: context, initialDate: initial.isBefore(now) ? now : initial, firstDate: DateTime(now.year, now.month, now.day), lastDate: now.add(const Duration(days: 365)));
    if (date == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(initial));
    if (time == null || !mounted) return;
    setState(() { final chosen = DateTime(date.year,date.month,date.day,time.hour,time.minute); start=chosen; });
  }
  final activities = const {'awake':'🐾 醒着','study':'✏️ 学习','music':'🎧 听歌','reading':'📖 读书','gaming':'🎮 打游戏','away':'🚪 暂时离开'};
  Future<void> setActivity(String activity) async {
    if(busy)return;setState(()=>busy=true);
    try{final body=<String,dynamic>{'activity':activity};if(me?['state']=='sleeping')body['state']='awake';apply(await api('update',body),loadFields:true);}catch(e){failed(e);}finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> customize(Map<String,dynamic> change) async {
    if(busy)return;setState(()=>busy=true);try{apply(await api('update',change));}catch(e){failed(e);}finally{if(mounted)setState(()=>busy=false);}
  }
  Widget appearancePicker({bool editing=false}) => LayoutBuilder(builder:(context,box)=>Wrap(spacing:6,runSpacing:6,children:List.generate(8,(index){
    final selected=(editing?me?['appearance']:selectedAppearance)==index;
    return SizedBox(width:(box.maxWidth-18)/4,height:122,child:InkWell(onTap:(){if(editing){customize({'appearance':index});}else{setState(()=>selectedAppearance=index);}},child:Container(decoration:BoxDecoration(color:selected?const Color(0xffffeed5):const Color(0xfff5eee4),borderRadius:BorderRadius.circular(14),border:Border.all(color:selected?Colors.brown:Colors.transparent,width:2)),child:Column(children:[Expanded(child:IgnorePointer(child:CatAvatar(slot:index,sleeping:false,empty:false))),Text(catNames[index],style:const TextStyle(fontSize:11)),const SizedBox(height:8)]))));
  })));
  Widget bedPicker()=>Wrap(spacing:8,runSpacing:8,children:List.generate(4,(index)=>ChoiceChip(label:Text('${bedNames[index]}${occupied.contains(index)?' · 已入住':''}'),selected:selectedBed==index,onSelected:occupied.contains(index)?null:(_)=>setState(()=>selectedBed=index))));
  String catName(String id){for(final c in cats){if(c['id']==id)return c['name'];}return '室友';}
  void composeNote(){
    bool sending=false;
    showModalBottomSheet(context:context,isScrollControlled:true,builder:(sheetContext)=>StatefulBuilder(builder:(ctx,change)=>Padding(padding:EdgeInsets.fromLTRB(22,22,22,MediaQuery.of(ctx).viewInsets.bottom+22),child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(children:[const Expanded(child:Text('写张小纸条',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))),IconButton(onPressed:()=>Navigator.pop(ctx),icon:const Icon(Icons.close))]),
      const Text('会贴在今天的公告板上，宿舍内可见。',style:TextStyle(color:Colors.brown,fontSize:12)),const SizedBox(height:14),
      DropdownButtonFormField<String>(initialValue:recipient,decoration:const InputDecoration(labelText:'留言给谁'),items:[const DropdownMenuItem(value:'all',child:Text('全体室友')),...cats.where((c)=>c['id']!=catId).map((c)=>DropdownMenuItem(value:c['id'] as String,child:Text(c['name'] as String)))],onChanged:(value)=>change(()=>recipient=value??'all')),
      const SizedBox(height:14),TextField(controller:message,maxLength:200,maxLines:4,decoration:const InputDecoration(labelText:'想和室友说的话')),
      Wrap(spacing:6,children:[ActionChip(label:const Text('☀️ 早起告知'),onPressed:()=>message.text='明早6:30要起床做志愿，洗漱、出门可能会有一点声音，提前跟大家说一声，我会尽量轻声～'),ActionChip(label:const Text('📚 明早有课'),onPressed:()=>message.text='明早有课，今晚想早点休息，谢谢大家～')]),
      if(error.isNotEmpty)Text(error,style:const TextStyle(color:Colors.red)),
      FilledButton(onPressed:sending?null:()async{change(()=>sending=true);final ok=await sendMessage();if(ctx.mounted){if(ok){Navigator.pop(ctx);}else{change(()=>sending=false);}}},child:Text(sending?'正在贴上…':'贴上公告板')),
    ])))));
  }
  void openNote(Map<String,dynamic> note){
    showDialog(context:context,builder:(ctx)=>AlertDialog(backgroundColor:const Color(0xfffff2c6),title:Text('给${note['recipient']=='all'?'全体室友':catName(note['recipient'])}的小纸条'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${catName(note['sender'])} · ${format(DateTime.fromMillisecondsSinceEpoch(((note['created'] as num)*1000).round()))}',style:const TextStyle(fontSize:12,color:Colors.brown)),const SizedBox(height:14),Text(note['body'],style:const TextStyle(height:1.9))])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('收好纸条')),if(note['sender']==catId)TextButton(onPressed:()async{try{apply(await api('delete-message',{'id':note['id']}));if(ctx.mounted)Navigator.pop(ctx);}catch(e){failed(e);}},child:const Text('删除我的纸条'))]));
  }
  Widget notesBoard(){
    final notes=data!['messages'] as List<dynamic>? ?? [];
    const colors=[Color(0xfffff0b9),Color(0xfff6d6d1),Color(0xffdce7cf),Color(0xffdbe7ef)];
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(children:[const Expanded(child:Text('小屋公告板',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))),TextButton.icon(onPressed:composeNote,icon:const Icon(Icons.add),label:const Text('贴张纸条'))]),
      const Text('今天的小事，轻轻说一声。',style:TextStyle(fontSize:12,color:Colors.brown)),const SizedBox(height:14),
      Container(constraints:const BoxConstraints(minHeight:420),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:const Color(0xffceaa7c),border:Border.all(color:const Color(0xffba8c61),width:9),borderRadius:BorderRadius.circular(18)),child:Column(children:[
        const Text('8-313 · 今日纸条',style:TextStyle(color:Color(0xff6e543e))),const SizedBox(height:24),
        if(notes.isEmpty)Transform.rotate(angle:-0.03,child:Container(padding:const EdgeInsets.all(30),color:const Color(0xfffff3cc),child:const Text('今天的公告板还空着\n贴张纸条，和室友说说吧 ♡',textAlign:TextAlign.center,style:TextStyle(height:2,color:Colors.brown)))),
        LayoutBuilder(builder:(ctx,box)=>Wrap(spacing:12,runSpacing:22,children:List.generate(notes.length,(index){final note=Map<String,dynamic>.from(notes[index]);return SizedBox(width:(box.maxWidth-12)/2,child:Transform.rotate(angle:index.isEven?-0.03:0.03,child:InkWell(onTap:()=>openNote(note),child:Container(constraints:const BoxConstraints(minHeight:160),padding:const EdgeInsets.fromLTRB(12,18,12,14),decoration:BoxDecoration(color:colors[index%4],boxShadow:const [BoxShadow(color:Color(0x3378512d),offset:Offset(2,5),blurRadius:6)]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Center(child:Icon(Icons.push_pin,size:13,color:Color(0xffc67f6f))),const SizedBox(height:8),Text('${catName(note['sender'])} → ${note['recipient']=='all'?'全体室友':catName(note['recipient'])}',style:const TextStyle(fontSize:10,color:Colors.brown)),const SizedBox(height:10),Text(note['body'],maxLines:7,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:13,height:1.8))])))));}))),
      ])),const SizedBox(height:12),const Text('只展示今天的留言 · 北京时间零点后自动隐藏',textAlign:TextAlign.center,style:TextStyle(fontSize:11,color:Colors.brown)),
    ]);
  }
  Widget panel(List<Widget> children) => Card(margin: const EdgeInsets.symmetric(vertical: 12), color: const Color(0xfffffdf8), elevation: 0,
    child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children)));
  Widget button(String label, VoidCallback call) => FilledButton.tonal(onPressed: busy ? null : call, child: Text(label));
  void detail(Map<String,dynamic> cat) {
    showDialog(context: context, builder: (ctx) => AlertDialog(title: Text(cat['name']), content: Text(
      '${cat['state']=='sleeping'?'休息中，zzz':cat['state']=='scheduled'?'已预约休息':'醒着，轻轻活动'}${cat['reason']==''?'':'\n留言：${cat['reason']}'}'), actions: [TextButton(onPressed: ()=>Navigator.pop(ctx), child: const Text('知道啦'))]));
  }
  @override Widget build(BuildContext context) => Scaffold(bottomNavigationBar:data==null?null:NavigationBar(selectedIndex:page,onDestinationSelected:(index)=>setState(()=>page=index),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),label:'小屋'),NavigationDestination(icon:Icon(Icons.pets_outlined),label:'状态'),NavigationDestination(icon:Icon(Icons.mail_outline),label:'留言'),NavigationDestination(icon:Icon(Icons.person_outline),label:'我的')]),body: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 560), child: ListView(padding: const EdgeInsets.all(22), children: [
    if(data==null) Row(children: [const Text('☾ 今晚也轻轻的'), const Spacer(), Text(online?'● 已同步':'○ 未连接', style: const TextStyle(fontSize: 12))]),
    const SizedBox(height: 8), const Text('宿舍小屋 · 8-313', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
    if(data==null) const Text('四只小猫，一个小小的家。', style: TextStyle(color: Colors.brown)),
    if (data == null) ...[
      const SizedBox(height:20),
      panel([
        const Text('让你的小猫住进来', style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold)), const SizedBox(height: 16),
        TextField(controller: server, decoration: const InputDecoration(labelText: '宿舍服务器地址', helperText: '填写电脑的局域网 IP，手机和电脑需互通')), const SizedBox(height: 16),
        const Text('先选床位'),const SizedBox(height:8),bedPicker(),const SizedBox(height:18),const Text('再选形象 · 入住后可切换'),const SizedBox(height:12),
        appearancePicker(), const SizedBox(height:14),
        TextField(controller: name, maxLength: 16, decoration: const InputDecoration(labelText: '给小猫取个名字')),
        TextField(controller: room, onChanged:(_)=>checkRoom(), keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(labelText: '宿舍邀请码 · 加入时填写')),
        Row(children: [Expanded(child: button('创建宿舍', ()=>enter(true))), const SizedBox(width: 10), Expanded(child: button('加入宿舍', ()=>enter(false)))]),
        if (token.isNotEmpty) TextButton(onPressed: ()=>refresh(loadFields:true), child: const Text('重连已保存的宿舍')),
      ])
    ] else ...[
      if (notice.isNotEmpty) panel([Text(notice),TextButton(onPressed:()=>setState(()=>notice=''),child:const Text('知道啦'))]),
      if(page==0)...[
      ClipRRect(borderRadius: BorderRadius.circular(26),child: AspectRatio(aspectRatio:4/5,child: LayoutBuilder(builder:(context,box)=>Stack(children:[
        Positioned.fill(child:Image.asset('assets/room.png',fit:BoxFit.cover)),Positioned.fill(child:CustomPaint(painter:LinenPainter(cats,linenColors))),
        Positioned(top:box.maxHeight*0.025,left:box.maxWidth*0.18,right:box.maxWidth*0.18,child:Container(padding:const EdgeInsets.all(9),decoration:BoxDecoration(color:const Color(0xeefff8e9),borderRadius:BorderRadius.circular(18)),child:Text(roomMood,textAlign:TextAlign.center,style:const TextStyle(fontSize:10)))),
        ...List.generate(4,(slot){
          final positions=[0,2,1,3];
          final pos=positions[slot];
          Map<String,dynamic>? current;
          for(final c in cats){if(c['slot']==slot) current=Map<String,dynamic>.from(c);}
          final cat=current;
          return Positioned(left:box.maxWidth*(pos % 2 == 0 ? 0.05 : 0.68),top:box.maxHeight*(pos < 2 ? 0.19 : 0.47),width:box.maxWidth*0.27,height:box.maxHeight*0.29,
            child:InkWell(onTap:cat==null?null:()=>detail(cat),child:Column(children:[
              Expanded(child:CatAvatar(slot:cat?['appearance'] ?? slot,sleeping:cat?['state']=='sleeping',empty:cat==null,activity:cat?['activity'] ?? 'awake')),
              Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:4),decoration:BoxDecoration(color:const Color(0xeefff7e9),borderRadius:BorderRadius.circular(10)),child:Text(cat==null?'等一位室友':'${cat['name']}${cat['id']==catId?' · 我':''}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11,fontWeight:FontWeight.bold))),
              Text(cat==null?'分享邀请码入住':cat['state']=='sleeping'?'休息中 · zzz':'${activities[cat['activity']] ?? activities['awake']}${cat['state']=='scheduled'?' · 已预约':''}',style:const TextStyle(fontSize:10,color:Color(0xff624d41))),
            ])));
        }),
      ])))),
      ],
      if(page==1)...[
      panel([const Text('我正在做什么',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:12),Wrap(spacing:8,runSpacing:6,children:activities.entries.map((entry)=>ChoiceChip(label:Text(entry.value),selected:me?['state']!='sleeping'&&me?['activity']==entry.key,onSelected:busy?null:(_)=>setActivity(entry.key))).toList()),const SizedBox(height:8),const Text('选择日常状态会结束当前休息；预约的休息计划继续保留。',style:TextStyle(fontSize:12,color:Colors.brown))]),
      panel([const Text('准备休息啦',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:12),
        Wrap(spacing:10,children:[ChoiceChip(label:const Text('现在休息'),selected:!scheduledMode,onSelected:(_)=>setState(()=>scheduledMode=false)),ChoiceChip(label:const Text('预约休息'),selected:scheduledMode,onSelected:(_)=>setState(()=>scheduledMode=true))]),
        if(scheduledMode) ListTile(contentPadding:EdgeInsets.zero,title:const Text('什么时候开始'),subtitle:Text(format(start)),trailing:const Icon(Icons.schedule),onTap:()=>choose()),
        const SizedBox(height:12),TextField(controller:reason,maxLength:120,maxLines:2,decoration:const InputDecoration(labelText:'休息原因 · 可不填')),
        Wrap(spacing:6,children:['太累了，想早点休息','身体不舒服，希望安静休息','明天做志愿，得早点起床'].map((text)=>ActionChip(label:Text(text),onPressed:()=>reason.text=text)).toList()),
        const SizedBox(height:12),button(scheduledMode?'保存预约':'确认休息 · 请室友轻声一点',()=>save(scheduledMode?'scheduled':'sleeping')),
        if(me?['state']=='sleeping') TextButton(onPressed:busy?null:()=>save('awake'),child:const Text('我醒啦 · 结束休息')),
      ]),
      ],
      if(page==2) notesBoard(),
      if(page==3)...[
      const SizedBox(height: 20), Row(children: [Text('8-313 · ${data!['room']}',style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), TextButton(onPressed: () async {await Clipboard.setData(ClipboardData(text: '${data!['room']}')); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('邀请码已复制')));}, child: const Text('复制邀请码'))]),
      Text('我的床位 · ${bedNames[me!['slot']]}'),
      panel([const Text('随时换个小猫形象',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:12),appearancePicker(editing:true)]),
      panel([const Text('我的床单颜色',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Wrap(spacing:8,children:linenColors.entries.map((entry)=>ChoiceChip(avatar:CircleAvatar(backgroundColor:entry.value),label:Text(linenNames[entry.key]!),selected:me?['bedding']==entry.key,onSelected:busy?null:(_)=>customize({'bedding':entry.key}))).toList())]),
      panel([const Text('床单样式',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Wrap(spacing:8,children:styleNames.entries.map((entry)=>ChoiceChip(label:Text(entry.value),selected:me?['style']==entry.key,onSelected:busy?null:(_)=>customize({'style':entry.key}))).toList())]),
      panel([ExpansionTile(title:const Text('我的小猫 · 修改名字'),children:[TextField(controller:name,maxLength:16,decoration:const InputDecoration(labelText:'小猫名字')),button('保存名字',()=>save(null))])]),
      ],
      if(page==3) const Text('休息状态由本人设置，应用打开时同步提醒。\n后台系统推送尚未接入。',textAlign: TextAlign.center,style: TextStyle(fontSize: 12,color: Colors.brown)),
    ],
    if(error.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 12),child: Text(error,style: const TextStyle(color: Colors.red))),
    if(busy) const LinearProgressIndicator(),
  ])))));
  @override void dispose() { WidgetsBinding.instance.removeObserver(this); timer?.cancel(); client.close(force:true); for(final c in [server,name,room,reason,message]) {c.dispose();} super.dispose(); }
}

class CatAvatar extends StatefulWidget {
  final int slot; final bool sleeping, empty; final String activity;
  const CatAvatar({super.key,required this.slot,required this.sleeping,required this.empty,this.activity='awake'});
  @override State<CatAvatar> createState()=>_CatAvatarState();
}
class _CatAvatarState extends State<CatAvatar> with SingleTickerProviderStateMixin {
  late final AnimationController animation=AnimationController(vsync:this,duration:const Duration(seconds:3))..repeat(reverse:true);
  ui.Image? atlas, activityAtlas, awakeAtlas, extraAtlas;
  bool poked=false;
  Timer? pokeTimer;
  void poke(){if(widget.empty)return;pokeTimer?.cancel();setState(()=>poked=true);pokeTimer=Timer(const Duration(milliseconds:1600),(){if(mounted)setState(()=>poked=false);});}
  @override void initState(){super.initState();load();}
  Future<void> load() async {for(final file in ['cats','activities','awake','extra']){final bytes=await rootBundle.load('assets/$file.png');final codec=await ui.instantiateImageCodec(bytes.buffer.asUint8List());final frame=await codec.getNextFrame();codec.dispose();if(mounted){setState((){if(file=='cats'){atlas=frame.image;}else if(file=='activities'){activityAtlas=frame.image;}else if(file=='awake'){awakeAtlas=frame.image;}else{extraAtlas=frame.image;}});}else{frame.image.dispose();}}}
  @override Widget build(BuildContext context)=>Semantics(label:widget.empty?'等待室友入住':'戳戳小猫的脸',button:!widget.empty,child:GestureDetector(onTap:widget.empty?null:poke,child:Stack(clipBehavior:Clip.none,children:[
    Positioned.fill(child:AnimatedScale(scale:poked?0.94:1,duration:const Duration(milliseconds:180),child:AnimatedBuilder(animation:animation,builder:(context,_)=>Opacity(opacity:widget.empty?0:1,child:Transform.translate(offset:Offset(0,MediaQuery.of(context).disableAnimations?0:animation.value*2),child:CustomPaint(painter:CatPainter(atlas,activityAtlas,awakeAtlas,extraAtlas,widget.slot,widget.sleeping,widget.activity),child:const SizedBox.expand())))))),
    if(poked) Positioned(top:0,left:-12,right:-12,child:Container(padding:const EdgeInsets.all(6),decoration:BoxDecoration(color:const Color(0xfffff8e9),borderRadius:BorderRadius.circular(12)),child:Text(widget.sleeping?'嘘～正在做梦 💤':widget.activity=='study'?'做完这题就来喵 ✏️':widget.activity=='music'?'分你一只耳机 🎧':widget.activity=='reading'?'陪我再看一页喵 📖':widget.activity=='gaming'?'这局结束就来喵 🎮':'喵～贴贴 ♡',textAlign:TextAlign.center,style:const TextStyle(fontSize:10)))),
  ])));
  @override void dispose(){pokeTimer?.cancel();animation.dispose();atlas?.dispose();activityAtlas?.dispose();awakeAtlas?.dispose();extraAtlas?.dispose();super.dispose();}
}
class CatPainter extends CustomPainter {
  final ui.Image? atlas, activityAtlas, awakeAtlas, extraAtlas;final int slot;final bool sleeping;final String activity;
  CatPainter(this.atlas,this.activityAtlas,this.awakeAtlas,this.extraAtlas,this.slot,this.sleeping,this.activity);
  @override void paint(Canvas canvas,Size size){
    if(activity=='away'&&!sleeping){final text=TextPainter(text:const TextSpan(text:'🚪 外出中',style:TextStyle(fontSize:16,color:Color(0xff79637d))),textDirection:TextDirection.ltr)..layout();text.paint(canvas,Offset((size.width-text.width)/2,size.height/2));return;}
    final row=['study','music','reading','gaming'].indexOf(activity);
    final useActivity=!sleeping&&row>=0&&activityAtlas!=null;
    final useAwake=!sleeping&&!useActivity&&awakeAtlas!=null;
    final useExtra=slot>=4&&extraAtlas!=null;
    final image=useExtra?extraAtlas:useActivity?activityAtlas:useAwake?awakeAtlas:atlas;if(image==null)return;
    final source=useExtra?Rect.fromLTWH((slot%4)*image.width/4,(sleeping?5:row<0?0:row+1)*image.height/6,image.width/4,image.height/6):useActivity?Rect.fromLTWH(slot*image.width/4,row*image.height/4,image.width/4,image.height/4):useAwake?Rect.fromLTWH(slot*image.width/4,(image.height-image.width/4)/2,image.width/4,image.width/4):Rect.fromLTWH(slot*image.width/4,image.height*(sleeping ? 0.5703125 : 0.125),image.width/4,image.height*0.3125);
    final fitted=applyBoxFit(BoxFit.contain,source.size,size);
    final target=Alignment.bottomCenter.inscribe(fitted.destination,Offset.zero & size);
    canvas.drawImageRect(image,source,target,Paint()..filterQuality=FilterQuality.high);
    if(sleeping){final text=TextPainter(text:const TextSpan(text:'zzz',style:TextStyle(fontSize:16,color:Color(0xff79637d),fontWeight:FontWeight.bold)),textDirection:TextDirection.ltr)..layout();text.paint(canvas,Offset(size.width-30,4));}
  }
  @override bool shouldRepaint(CatPainter old)=>atlas!=old.atlas||activityAtlas!=old.activityAtlas||awakeAtlas!=old.awakeAtlas||extraAtlas!=old.extraAtlas||activity!=old.activity||slot!=old.slot||sleeping!=old.sleeping;
}

class LinenPainter extends CustomPainter {
 final List<dynamic> cats;final Map<String,Color> colors;
 LinenPainter(this.cats,this.colors);
 @override void paint(Canvas canvas,Size size){
  const shapes=[[[0.035,0.335],[0.12,0.328],[0.345,0.34],[0.36,0.36],[0.36,0.385],[0.04,0.405]],[[0.035,0.624],[0.12,0.609],[0.35,0.635],[0.36,0.653],[0.35,0.70],[0.035,0.725]],[[0.965,0.335],[0.88,0.328],[0.655,0.34],[0.64,0.36],[0.64,0.385],[0.96,0.405]],[[0.965,0.624],[0.88,0.609],[0.65,0.635],[0.64,0.653],[0.65,0.70],[0.965,0.725]]];
  for(final cat in cats){if((cat['bedding']==null||cat['bedding']=='original')&&(cat['style']==null||cat['style']=='original'))continue;final path=Path();final points=shapes[cat['slot'] as int];path.moveTo(points.first[0]*size.width,points.first[1]*size.height);for(final p in points.skip(1)){path.lineTo(p[0]*size.width,p[1]*size.height);}path.close();canvas.drawPath(path,Paint()..color=(colors[cat['bedding']]??Colors.transparent).withAlpha(200)..blendMode=BlendMode.color);final style=cat['style']??'original';if(style!='original'){canvas.save();canvas.clipPath(path);canvas.drawPath(path,Paint()..color=cat['bedding']=='original'?const Color(0xfff3d5a8):(colors[cat['bedding']]??const Color(0xfff3d5a8)));if(style=='plain'){canvas.drawPath(path,Paint()..color=(colors[cat['bedding']]??const Color(0xfff3d5a8)).withAlpha(230));}else{final ink=Paint()..color=const Color(0x99fff6d9)..strokeWidth=3;for(double y=0;y<size.height;y+=18){for(double x=0;x<size.width;x+=18){if(style=='gingham'){canvas.drawRect(Rect.fromLTWH(x,y,9,9),ink);}else if(style=='stripes'){canvas.drawLine(Offset(x,y),Offset(x+12,y+12),ink);}else{final tp=TextPainter(text:TextSpan(text:style=='stars'?'★':'🐾',style:const TextStyle(fontSize:13,color:Color(0xbbfff6d9))),textDirection:TextDirection.ltr)..layout();tp.paint(canvas,Offset(x,y));}}}}canvas.restore();}}
 }
 @override bool shouldRepaint(LinenPainter old)=>true;
}
