#!/bin/sh
set -eu
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT}"
: "${JAVA_HOME:?Set JAVA_HOME}"
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD_DIR=${DORM_BUILD_DIR:-"$ROOT/build"}
OUT=${DORM_APK_OUT:-"$ROOT/dorm-cottage-android-test.apk"}
TOOLS="$ANDROID_SDK_ROOT/build-tools/35.0.1"
PLATFORM="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
mkdir -p "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$BUILD_DIR/resources" "$BUILD_DIR/generated" "$BUILD_DIR/assets"
cp "$ROOT/../preview/index.html" "$BUILD_DIR/assets/index.html"
cp "$ROOT/../app/assets/"*.png "$BUILD_DIR/assets/"
if [ -d "$ROOT/assets" ]; then cp "$ROOT/assets/"* "$BUILD_DIR/assets/"; fi
"$TOOLS/aapt2" compile --dir "$ROOT/res" -o "$BUILD_DIR/resources.zip"
"$TOOLS/aapt2" link -o "$BUILD_DIR/base.apk" -I "$PLATFORM" --manifest "$ROOT/AndroidManifest.xml" --java "$BUILD_DIR/generated" -A "$BUILD_DIR/assets" "$BUILD_DIR/resources.zip"
"$JAVA_HOME/bin/javac" -encoding UTF-8 -source 8 -target 8 -classpath "$PLATFORM" -d "$BUILD_DIR/classes" "$ROOT/src/cn/dorm/cottage/"*.java "$BUILD_DIR/generated/cn/dorm/cottage/R.java"
"$JAVA_HOME/bin/jar" cf "$BUILD_DIR/classes.jar" -C "$BUILD_DIR/classes" .
"$TOOLS/d8" --lib "$PLATFORM" --min-api 26 --output "$BUILD_DIR/dex" "$BUILD_DIR/classes.jar"
cp "$BUILD_DIR/base.apk" "$BUILD_DIR/unsigned.apk"
(cd "$BUILD_DIR/dex" && /usr/bin/zip -q -u "$BUILD_DIR/unsigned.apk" classes.dex)
"$TOOLS/zipalign" -f -p 4 "$BUILD_DIR/unsigned.apk" "$BUILD_DIR/aligned.apk"
KEY="$BUILD_DIR/dorm-debug.jks"
if [ ! -f "$KEY" ]; then
  "$JAVA_HOME/bin/keytool" -genkeypair -keystore "$KEY" -storepass android -keypass android -alias androiddebugkey -dname 'CN=Dorm Cottage Test,O=Local Development,C=CN' -keyalg RSA -keysize 2048 -validity 10000
fi
"$TOOLS/apksigner" sign --ks "$KEY" --ks-pass pass:android --key-pass pass:android --out "$OUT" "$BUILD_DIR/aligned.apk"
"$TOOLS/apksigner" verify --verbose "$OUT"
echo "APK: $OUT"
