package cn.dorm.cottage;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import org.json.*;
import java.security.SecureRandom;
import java.time.*;
import java.util.*;

/** Phone-owned persistent rooms; all mutations are serialized by the store. */
public final class DormStore extends SQLiteOpenHelper {
    static final class Problem extends Exception {
        final int status;
        Problem(int status,String message){super(message);this.status=status;}
    }
    private final SecureRandom random=new SecureRandom();
    public DormStore(Context c){super(c,"dorm-local-v1.sqlite",null,1);}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE rooms(code TEXT PRIMARY KEY,name TEXT,created REAL)");
        db.execSQL("CREATE TABLE cats(id TEXT PRIMARY KEY,room TEXT,slot INTEGER,appearance INTEGER,bedding TEXT DEFAULT 'original',style TEXT DEFAULT 'original',token TEXT UNIQUE,name TEXT,state TEXT DEFAULT 'awake',activity TEXT DEFAULT 'awake',reason TEXT DEFAULT '',start TEXT DEFAULT '',end TEXT DEFAULT '',updated REAL,UNIQUE(room,slot))");
        db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT,room TEXT,cat TEXT,name TEXT,reason TEXT,created REAL)");
        db.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT,room TEXT,sender TEXT,recipient TEXT,body TEXT,created REAL,deleted INTEGER DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}
    static double now(){return System.currentTimeMillis()/1000.0;}
    static String text(JSONObject value,String key,String fallback,int max){String s=value.optString(key,fallback).trim();return s.length()>max?s.substring(0,max):s;}
    static String[] args(String...a){return a;}
    private JSONObject one(String sql,String...params)throws Exception{try(Cursor c=getReadableDatabase().rawQuery(sql,params)){return c.moveToFirst()?row(c):null;}}
    private JSONArray all(String sql,String...params)throws Exception{JSONArray a=new JSONArray();try(Cursor c=getReadableDatabase().rawQuery(sql,params)){while(c.moveToNext())a.put(row(c));}return a;}
    static JSONObject row(Cursor c)throws Exception{JSONObject out=new JSONObject();for(int i=0;i<c.getColumnCount();i++){switch(c.getType(i)){case Cursor.FIELD_TYPE_INTEGER:out.put(c.getColumnName(i),c.getLong(i));break;case Cursor.FIELD_TYPE_FLOAT:out.put(c.getColumnName(i),c.getDouble(i));break;case Cursor.FIELD_TYPE_NULL:out.put(c.getColumnName(i),JSONObject.NULL);break;default:out.put(c.getColumnName(i),c.getString(i));}}return out;}
    public synchronized boolean hasRoom(String code){try{return one("SELECT code FROM rooms WHERE code=?",code)!=null;}catch(Exception e){return false;}}
    static void require(boolean good,String message)throws Problem{if(!good)throw new Problem(400,message);}
    static boolean among(String value,String...values){for(String v:values)if(v.equals(value))return true;return false;}
    private String key(){byte[] b=new byte[24];random.nextBytes(b);StringBuilder s=new StringBuilder();for(byte n:b)s.append(String.format(Locale.US,"%02x",n));return s.toString();}
    static double instant(String input)throws Problem{try{return OffsetDateTime.parse(input).toInstant().toEpochMilli()/1000.0;}catch(Exception e){throw new Problem(400,"请选择有效的预约时间");}}
    private void event(String room,String cat,String name,String reason){getWritableDatabase().execSQL("INSERT INTO events(room,cat,name,reason,created) VALUES(?,?,?,?,?)",new Object[]{room,cat,name,reason,now()});}
    private void evolve(String room)throws Exception{
        JSONArray cats=all("SELECT * FROM cats WHERE room=? AND state='scheduled'",room);
        for(int i=0;i<cats.length();i++){JSONObject c=cats.getJSONObject(i);if(instant(c.getString("start"))<=now()){
            getWritableDatabase().execSQL("UPDATE cats SET state='sleeping',updated=? WHERE id=?",new Object[]{now(),c.getString("id")});event(room,c.getString("id"),c.getString("name"),c.getString("reason"));
        }}
    }
    private JSONObject state(String room)throws Exception{
        evolve(room);JSONObject r=one("SELECT name FROM rooms WHERE code=?",room);
        long day=LocalDate.now(ZoneId.of("Asia/Shanghai")).atStartOfDay(ZoneId.of("Asia/Shanghai")).toEpochSecond();
        return new JSONObject().put("room",room).put("roomName",r.getString("name"))
            .put("cats",all("SELECT id,slot,appearance,bedding,style,name,state,activity,reason,start,end,updated FROM cats WHERE room=? ORDER BY slot",room))
            .put("events",all("SELECT * FROM (SELECT id,cat,name,reason,created FROM events WHERE room=? ORDER BY id DESC LIMIT 100) ORDER BY id",room))
            .put("messages",all("SELECT id,sender,recipient,body,created FROM messages WHERE room=? AND deleted=0 AND created>=? AND created<? ORDER BY id DESC LIMIT 50",room,String.valueOf(day),String.valueOf(day+86400)))
            .put("serverTime",now());
    }
    public synchronized JSONObject api(String path,JSONObject data,String token)throws Exception{
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{JSONObject result=handle(path,data,token);db.setTransactionSuccessful();return result;}finally{db.endTransaction();}
    }
    private JSONObject handle(String path,JSONObject data,String token)throws Exception{
        SQLiteDatabase db=getWritableDatabase();
        if(path.equals("preview")){
            String room=data.optString("room");require(hasRoom(room),"没有找到这个宿舍");JSONArray occupied=new JSONArray();JSONArray cats=all("SELECT slot FROM cats WHERE room=?",room);for(int i=0;i<cats.length();i++)occupied.put(cats.getJSONObject(i).getInt("slot"));return new JSONObject().put("occupied",occupied);
        }
        if(path.equals("create")||path.equals("join")){
            String name=text(data,"name","",16);require(!name.isEmpty(),"请给小猫取个名字");String room=data.optString("room");
            if(path.equals("create")){
                do{room=String.valueOf(random.nextInt(900000)+100000);}while(hasRoom(room));String roomName=text(data,"roomName","",24);require(!roomName.isEmpty(),"请填写宿舍名称");db.execSQL("INSERT INTO rooms VALUES(?,?,?)",new Object[]{room,roomName,now()});
            }else require(hasRoom(room),"没有找到这个宿舍");
            int slot=data.optInt("slot",-1),appearance=data.optInt("appearance",0);require(slot>=0&&slot<4,"请选择床位");require(appearance>=0&&appearance<8,"请选择形象");require(one("SELECT id FROM cats WHERE room=? AND slot=?",room,String.valueOf(slot))==null,"这个床位已经有人啦，请换一个");
            String id=key(),secret=key();db.execSQL("INSERT INTO cats(id,room,slot,appearance,token,name,updated) VALUES(?,?,?,?,?,?,?)",new Object[]{id,room,slot,appearance,secret,name,now()});return state(room).put("token",secret).put("id",id);
        }
        JSONObject c=one("SELECT * FROM cats WHERE token=?",token);
        if(c==null)throw new Problem(401,"身份已失效，请重新加入宿舍");String room=c.getString("room"),id=c.getString("id");evolve(room);c=one("SELECT * FROM cats WHERE id=?",id);
        if(path.equals("leave")){db.execSQL("DELETE FROM cats WHERE id=?",new Object[]{id});return new JSONObject().put("left",true);}
        if(path.equals("update")){
            String name=text(data,"name",c.getString("name"),16),state=data.optString("state",c.getString("state")),activity=data.optString("activity",c.getString("activity")),bedding=data.optString("bedding",c.getString("bedding")),style=data.optString("style",c.getString("style")),reason=text(data,"reason",c.getString("reason"),120),start=data.optString("start",c.getString("start"));
            int appearance=data.optInt("appearance",c.getInt("appearance"));require(!name.isEmpty(),"请填写名字");require(among(state,"awake","sleeping","scheduled"),"休息状态无效");require(among(activity,"awake","study","music","reading","gaming","away"),"日常状态无效");require(among(bedding,"original","cream","peach","blue","mint","lavender"),"床单颜色无效");require(among(style,"original","plain","gingham","stripes","stars","paws"),"床单样式无效");require(appearance>=0&&appearance<8,"形象无效");
            if(state.equals("scheduled"))require(instant(start)>now(),"预约时间需要晚于现在");
            else if(state.equals("awake")){start="";reason="";}else if(!c.getString("state").equals("sleeping"))start=OffsetDateTime.now(ZoneOffset.UTC).toString();
            db.execSQL("UPDATE cats SET name=?,state=?,activity=?,appearance=?,bedding=?,style=?,reason=?,start=?,end='',updated=? WHERE id=?",new Object[]{name,state,activity,appearance,bedding,style,reason,start,now(),id});
            if(state.equals("sleeping")&&!c.getString("state").equals("sleeping"))event(room,id,name,reason);
        }else if(path.equals("message")){
            String body=text(data,"body","",201),recipient=data.optString("recipient","all");require(!body.isEmpty()&&body.length()<=200,"留言需为1—200字");require(recipient.equals("all")||one("SELECT id FROM cats WHERE room=? AND id=?",room,recipient)!=null,"这位室友不在宿舍");db.execSQL("INSERT INTO messages(room,sender,recipient,body,created) VALUES(?,?,?,?,?)",new Object[]{room,id,recipient,body,now()});
        }else if(path.equals("delete-message")){
            long noteId=data.optLong("id",-1);JSONObject note=one("SELECT sender FROM messages WHERE id=? AND room=?",String.valueOf(noteId),room);if(note==null||!note.getString("sender").equals(id))throw new Problem(403,"只能删除自己写的纸条");db.execSQL("UPDATE messages SET deleted=1 WHERE id=?",new Object[]{noteId});
        }else if(!path.equals("state"))throw new Problem(404,"接口不存在");
        return state(room);
    }
}
