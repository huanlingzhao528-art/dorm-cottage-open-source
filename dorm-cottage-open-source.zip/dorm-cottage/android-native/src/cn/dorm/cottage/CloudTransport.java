package cn.dorm.cottage;
import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** HTTPS RPC client. Only the public anon key is bundled, never an administrator key. */
final class CloudTransport {
    private final String endpoint,key;
    CloudTransport(Context context)throws Exception {
        try(InputStream in=context.getAssets().open("cloud-config.json")){
            JSONObject c=new JSONObject(new String(PeerServer.read(in,16384),StandardCharsets.UTF_8));
            endpoint=c.getString("endpoint");key=c.getString("publishableKey");
            URL url=new URL(endpoint);if(!url.getProtocol().equals("https")||!url.getHost().endsWith(".api.tcloudbasegateway.com"))throw new IOException("Invalid cloud endpoint");
        }
    }
    JSONObject request(String action,JSONObject data,String token)throws Exception {
        if(action.equals("preview")||action.equals("join")){
            String room=data.optString("room","").trim();
            if(!room.matches("[0-9]{6}"))throw new DormStore.Problem(400,"请输入六位云端邀请码；旧版热点宿舍需在云端重新创建");
        }
        if(!action.equals("create")&&!action.equals("join")&&!action.equals("preview")&&!token.matches("[0-9]{6}:[a-f0-9]{64}"))throw new DormStore.Problem(401,"已切换云端同步，请重新创建或加入云端宿舍");
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection(Proxy.NO_PROXY);
        try{
            c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestMethod("POST");c.setUseCaches(false);
            c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+key);c.setDoOutput(true);
            byte[] bytes=new JSONObject().put("p_action",action).put("p_data",data).put("p_token",token).toString().getBytes(StandardCharsets.UTF_8);
            try(OutputStream out=c.getOutputStream()){out.write(bytes);}
            int status=c.getResponseCode();JSONObject result=new JSONObject(new String(PeerServer.read(status>=400?c.getErrorStream():c.getInputStream(),1000000),StandardCharsets.UTF_8));
            if(status>=400)throw new DormStore.Problem(status,result.optString("message",result.optString("error","云端暂时无法连接，请稍后重试")));
            return result;
        }catch(SocketTimeoutException e){throw new DormStore.Problem(503,"云端连接超时，请检查手机网络后重试");}
        finally{c.disconnect();}
    }
}
