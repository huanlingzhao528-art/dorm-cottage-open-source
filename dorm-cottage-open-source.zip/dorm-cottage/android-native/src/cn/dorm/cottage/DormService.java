package cn.dorm.cottage;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.*;
import org.json.*;
import java.util.concurrent.*;

/** Explicit, visible phone-to-phone connection service. No computer connection. */
public final class DormService extends Service {
    public static volatile DormService instance;
    public volatile PeerServer peer;
    public volatile String failure="";
    private ScheduledExecutorService timer;
    private WifiManager.MulticastLock multicast;
    private volatile boolean appVisible;
    private final Object cursorLock=new Object();
    public void setVisible(boolean visible){appVisible=visible;}
    @Override public void onCreate(){
        super.onCreate();instance=this;
        NotificationManager manager=getSystemService(NotificationManager.class);
        NotificationChannel connection=new NotificationChannel("dorm-connection","小屋设备连接",NotificationManager.IMPORTANCE_LOW);connection.setSound(null,null);manager.createNotificationChannel(connection);
        NotificationChannel reminders=new NotificationChannel("dorm-reminders","室友轻提醒",NotificationManager.IMPORTANCE_DEFAULT);reminders.setSound(null,null);reminders.enableVibration(true);reminders.setVibrationPattern(new long[]{0,70});manager.createNotificationChannel(reminders);
        PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification ongoing=new Notification.Builder(this,"dorm-connection").setSmallIcon(cn.dorm.cottage.R.drawable.icon).setContentTitle("宿舍小屋 · 设备同步运行中").setContentText("云端同步开启 · 校园网、流量均可使用").setContentIntent(open).setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(1,ongoing,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);else startForeground(1,ongoing);
        try{WifiManager wifi=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);if(wifi!=null){multicast=wifi.createMulticastLock("dorm-room-discovery");multicast.setReferenceCounted(false);multicast.acquire();}}catch(Exception ignored){}
        try{peer=new PeerServer(this);peer.start();}catch(Exception e){failure="手机内置服务未能启动，请重启应用";}
        timer=Executors.newSingleThreadScheduledExecutor();timer.scheduleWithFixedDelay(this::checkReminders,10,60,TimeUnit.SECONDS);
    }
    public void registerSession(String token,String id,String room){
        synchronized(cursorLock){SharedPreferences p=getSharedPreferences("room-session",MODE_PRIVATE);if(!token.equals(p.getString("token",""))){p.edit().putString("token",token).putString("id",id).putString("room",room).remove("eventCursor").remove("noteCursor").apply();if(timer!=null)timer.execute(this::checkReminders);}}
    }
    public void acknowledge(long event,long note){synchronized(cursorLock){SharedPreferences p=getSharedPreferences("room-session",MODE_PRIVATE);p.edit().putLong("eventCursor",Math.max(event,p.getLong("eventCursor",0))).putLong("noteCursor",Math.max(note,p.getLong("noteCursor",0))).apply();}}
    public void clearSession(){synchronized(cursorLock){getSharedPreferences("room-session",MODE_PRIVATE).edit().clear().apply();}}
    private void checkReminders(){
        if(peer==null||appVisible)return;
        try{synchronized(cursorLock){SharedPreferences p=getSharedPreferences("room-session",MODE_PRIVATE);String token=p.getString("token",""),id=p.getString("id","");if(token.isEmpty())return;
            JSONObject snapshot=peer.route("state",new JSONObject(),token);JSONArray cats=snapshot.getJSONArray("cats");String state="awake";for(int i=0;i<cats.length();i++){JSONObject c=cats.getJSONObject(i);if(c.getString("id").equals(id))state=c.getString("state");}
            JSONArray events=snapshot.getJSONArray("events"),notes=snapshot.getJSONArray("messages");long eventCursor=p.getLong("eventCursor",-1),noteCursor=p.getLong("noteCursor",-1),maxEvent=eventCursor<0?0:eventCursor,maxNote=noteCursor<0?0:noteCursor;
            String message="";
            for(int i=0;i<events.length();i++){JSONObject e=events.getJSONObject(i);long seq=e.getLong("id");maxEvent=Math.max(maxEvent,seq);if(eventCursor>=0&&seq>eventCursor&&!e.getString("cat").equals(id)&&DormStore.now()-e.getDouble("created")<180)message=e.getString("name")+" 准备休息了，请轻声一点";}
            for(int i=0;i<notes.length();i++){JSONObject note=notes.getJSONObject(i);long seq=note.getLong("id");maxNote=Math.max(maxNote,seq);if(noteCursor>=0&&seq>noteCursor&&!note.getString("sender").equals(id)&&(note.getString("recipient").equals("all")||note.getString("recipient").equals(id)))message="室友贴了一张新的小纸条";}
            p.edit().putLong("eventCursor",maxEvent).putLong("noteCursor",maxNote).apply();
            if(!appVisible&&!state.equals("sleeping")&&!message.isEmpty()){
                PendingIntent open=PendingIntent.getActivity(this,2,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                Notification note=new Notification.Builder(this,"dorm-reminders").setSmallIcon(R.drawable.icon).setContentTitle("宿舍小屋").setContentText(message).setContentIntent(open).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).setOnlyAlertOnce(false).build();
                try{getSystemService(NotificationManager.class).notify(2,note);}catch(SecurityException ignored){}
            }
        }}catch(Exception ignored){}
    }
    @Override public void onTimeout(int startId,int type){
        Notification paused=new Notification.Builder(this,"dorm-connection").setSmallIcon(R.drawable.icon).setContentTitle("小屋后台同步已暂停").setContentText("系统限制了后台运行时长，打开小屋可继续同步").setContentIntent(PendingIntent.getActivity(this,3,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE)).setAutoCancel(true).build();
        getSystemService(NotificationManager.class).notify(3,paused);stopSelf();
    }
    @Override public int onStartCommand(Intent intent,int flags,int id){return START_STICKY;}
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onDestroy(){instance=null;if(timer!=null)timer.shutdownNow();if(peer!=null)peer.stop();if(multicast!=null&&multicast.isHeld())multicast.release();super.onDestroy();}
}
