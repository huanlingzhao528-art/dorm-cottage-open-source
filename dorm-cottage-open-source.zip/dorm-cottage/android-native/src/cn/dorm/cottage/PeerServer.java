package cn.dorm.cottage;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.util.Log;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Offline assets + phone-to-phone room transport. Never routes through a PC. */
public final class PeerServer {
    public static final int HTTP_PORT=18765,DISCOVERY_PORT=18766;
    final DormStore store;
    private final CloudTransport cloud;
    private final Context context;
    private final SharedPreferences prefs;
    private final ExecutorService workers=Executors.newFixedThreadPool(8);
    private final Map<String,String> discovered=new ConcurrentHashMap<>();
    private volatile boolean running=true;
    private ServerSocket listener;
    private DatagramSocket discovery;
    private volatile String remote;
    public PeerServer(Context context){this.context=context;store=new DormStore(context);prefs=context.getSharedPreferences("peer-state",Context.MODE_PRIVATE);remote=prefs.getString("remote","");CloudTransport candidate=null;try{candidate=new CloudTransport(context);}catch(Exception ignored){}cloud=candidate;}
    public void start()throws IOException{
        listener=new ServerSocket();listener.setReuseAddress(true);listener.bind(cloud!=null?new InetSocketAddress(InetAddress.getByName("127.0.0.1"),HTTP_PORT):new InetSocketAddress(HTTP_PORT));
        new Thread(()->{while(running){try{final Socket socket=listener.accept();workers.execute(()->serve(socket));}catch(Exception e){if(!running)break;}}},"dorm-http").start();
        if(cloud==null)new Thread(this::listenDiscovery,"dorm-discovery").start();
    }
    public void stop(){running=false;try{listener.close();}catch(Exception ignored){}if(discovery!=null)discovery.close();workers.shutdownNow();store.close();}
    void setRemote(String address){remote=address;prefs.edit().putString("remote",address).apply();}
    public String getRemote(){return cloud!=null?"腾讯云 · 上海":remote;}
    public boolean isCloud(){return cloud!=null;}
    public static String localIp(){
        String fallback="";try{Enumeration<NetworkInterface> all=NetworkInterface.getNetworkInterfaces();while(all.hasMoreElements()){NetworkInterface n=all.nextElement();if(!n.isUp()||n.isLoopback()||n.getName().startsWith("tun")||n.getName().startsWith("tap"))continue;for(InetAddress a:Collections.list(n.getInetAddresses())){if(a instanceof Inet4Address&&a.isSiteLocalAddress()){if(n.getName().contains("wlan")||n.getName().startsWith("ap"))return a.getHostAddress();fallback=a.getHostAddress();}}}}catch(Exception ignored){}return fallback;
    }
    public String invite(String room){if(cloud!=null)return room;String host=remote.isEmpty()?localIp()+":"+HTTP_PORT:remote;return host.startsWith(":")?room:room+"@"+host;}
    private void listenDiscovery(){
        try{discovery=new DatagramSocket(null);discovery.setReuseAddress(true);discovery.bind(new InetSocketAddress(DISCOVERY_PORT));byte[] bytes=new byte[256];while(running){DatagramPacket packet=new DatagramPacket(bytes,bytes.length);discovery.receive(packet);String query=new String(packet.getData(),0,packet.getLength(),StandardCharsets.UTF_8);if(query.startsWith("DORM_ROOM_V1:")){String code=query.substring(13).trim();if(store.hasRoom(code)){byte[] response=("DORM_FOUND_V1:"+code+":"+HTTP_PORT).getBytes(StandardCharsets.UTF_8);discovery.send(new DatagramPacket(response,response.length,packet.getAddress(),packet.getPort()));}}}}catch(Exception ignored){}
    }
    private String discover(String room)throws Exception{
        Set<InetAddress> targets=new HashSet<>();targets.add(InetAddress.getByName("255.255.255.255"));try{for(NetworkInterface n:Collections.list(NetworkInterface.getNetworkInterfaces()))for(InterfaceAddress a:n.getInterfaceAddresses())if(a.getBroadcast()!=null)targets.add(a.getBroadcast());}catch(Exception ignored){}
        try(DatagramSocket socket=new DatagramSocket()){
            socket.setBroadcast(true);socket.setSoTimeout(650);byte[] query=("DORM_ROOM_V1:"+room).getBytes(StandardCharsets.UTF_8);
            for(int pass=0;pass<3;pass++){
                for(InetAddress target:targets)try{socket.send(new DatagramPacket(query,query.length,target,DISCOVERY_PORT));}catch(Exception ignored){}
                long end=System.currentTimeMillis()+850;
                while(System.currentTimeMillis()<end){try{DatagramPacket answer=new DatagramPacket(new byte[256],256);socket.receive(answer);String text=new String(answer.getData(),0,answer.getLength(),StandardCharsets.UTF_8);if(text.equals("DORM_FOUND_V1:"+room+":"+HTTP_PORT))return answer.getAddress().getHostAddress()+":"+HTTP_PORT;}catch(SocketTimeoutException e){break;}}
            }
        }
        throw new DormStore.Problem(503,"没有发现宿舍。请确认创建者的手机已开启小屋、都在同一可互通的Wi-Fi；校园网可能隔离设备。也可粘贴舍友复制的完整邀请码，或换同一手机热点测试。");
    }
    private String validateHost(String value)throws Exception{
        String[] parts=value.split(":");if(parts.length!=2||!parts[1].equals(String.valueOf(HTTP_PORT)))throw new DormStore.Problem(400,"完整邀请码地址无效");
        if(!parts[0].matches("[0-9.]+"))throw new DormStore.Problem(400,"只支持宿舍局域网地址");InetAddress address=InetAddress.getByName(parts[0]);if(!(address instanceof Inet4Address)||(!address.isSiteLocalAddress()&&!address.isLinkLocalAddress()))throw new DormStore.Problem(400,"只支持宿舍局域网地址");return value;
    }
    public synchronized JSONObject route(String action,JSONObject body,String token)throws Exception{
        if(cloud!=null)return cloud.request(action,body,token);
        if(action.equals("create")){JSONObject result=store.api(action,body,token);setRemote("");return result;}
        if(action.equals("preview")||action.equals("join")){
            String input=body.optString("room","").trim();String[] parts=input.split("@",2);String code=parts[0];if(!code.matches("[0-9]{6}"))throw new DormStore.Problem(400,"请输入六位邀请码，或舍友复制的完整邀请码");body.put("room",code);
            String host=parts.length==2?validateHost(parts[1]):discovered.get(code);
            if(host==null&&!store.hasRoom(code))host=discover(code);
            if(host!=null){JSONObject result=forward(host,action,body,token);discovered.put(code,host);if(action.equals("join"))setRemote(host);return result;}
            JSONObject result=store.api(action,body,token);if(action.equals("join"))setRemote("");return result;
        }
        if(!remote.isEmpty()){
            JSONObject result=forward(remote,action,body,token);if(action.equals("leave"))setRemote("");return result;
        }
        return store.api(action,body,token);
    }
    private JSONObject forward(String host,String action,JSONObject body,String token)throws Exception{
        HttpURLConnection connection=openPeerConnection(host,action);
        try{
        connection.setConnectTimeout(3000);connection.setReadTimeout(5000);connection.setRequestMethod("POST");connection.setRequestProperty("Content-Type","application/json");connection.setRequestProperty("Authorization","Bearer "+token);connection.setDoOutput(true);connection.getOutputStream().write(body.toString().getBytes(StandardCharsets.UTF_8));int code=connection.getResponseCode();InputStream stream=code>=400?connection.getErrorStream():connection.getInputStream();String text=new String(read(stream,1000000),StandardCharsets.UTF_8);connection.disconnect();JSONObject result=new JSONObject(text);if(code>=400)throw new DormStore.Problem(code,result.optString("error","无法连接到创建宿舍的手机"));return result;
        }catch(SocketTimeoutException e){throw new DormStore.Problem(503,"连接 "+host+" 超时。请让创建者打开小屋，重新复制邀请码；若仍失败，请两台手机连接同一手机热点测试，校园网可能隔离设备。");}
        catch(ConnectException e){throw new DormStore.Problem(503,"无法连接 "+host+"。请确认创建者已打开小屋，邀请码中的地址是当前 Wi-Fi 地址。切换网络后需要重新复制邀请码。");}
        catch(NoRouteToHostException e){throw new DormStore.Problem(503,"无法到达 "+host+"。请检查 Wi-Fi、VPN 的局域网访问设置，或换同一手机热点测试。");}
        finally{connection.disconnect();}
    }
    // Select the physical Wi-Fi network explicitly, rather than the VPN default route.
    private HttpURLConnection openPeerConnection(String host,String action)throws Exception{
        URL url=new URL("http://"+validateHost(host)+"/api/"+action);
        ConnectivityManager manager=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(manager!=null)for(Network network:manager.getAllNetworks()){
            NetworkCapabilities caps=manager.getNetworkCapabilities(network);
            if(caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)&&!caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN))
                return (HttpURLConnection)network.openConnection(url,Proxy.NO_PROXY);
        }
        return (HttpURLConnection)url.openConnection(Proxy.NO_PROXY);
    }
    static byte[] read(InputStream stream,int max)throws IOException{if(stream==null)return new byte[0];ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] tmp=new byte[8192];for(int n;(n=stream.read(tmp))!=-1;){if(b.size()+n>max)throw new IOException("Response too large");b.write(tmp,0,n);}return b.toByteArray();}
    private static String line(InputStream in)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();for(int n;(n=in.read())!=-1;){if(n==10)break;if(n!=13)out.write(n);if(out.size()>16384)throw new IOException("Header too long");}return out.toString("UTF-8");}
    private void serve(Socket socket){try(Socket s=socket){s.setSoTimeout(7000);InputStream in=s.getInputStream();String first=line(in);String[] request=first.split(" ");if(request.length<2)return;String method=request[0],path=request[1].split("\\?",2)[0];int length=0;String token="";for(int count=0;count<60;count++){String h=line(in);if(h.isEmpty())break;String lower=h.toLowerCase(Locale.US);if(lower.startsWith("content-length:"))length=Integer.parseInt(h.substring(15).trim());if(lower.startsWith("authorization: bearer "))token=h.substring(22).trim();}
            if(method.equals("POST")&&path.startsWith("/api/")){
                if(length<0||length>8192){respond(s,400,"application/json",new JSONObject().put("error","请求过大").toString().getBytes(StandardCharsets.UTF_8));return;}
                byte[] body=new byte[length];int offset=0;while(offset<length){int n=in.read(body,offset,length-offset);if(n<0)throw new IOException("Incomplete body");offset+=n;}
                try{JSONObject payload=new JSONObject(new String(body,StandardCharsets.UTF_8));JSONObject result=s.getInetAddress().isLoopbackAddress()?route(path.substring(5),payload,token):store.api(path.substring(5),payload,token);respond(s,200,"application/json",result.toString().getBytes(StandardCharsets.UTF_8));}catch(DormStore.Problem e){respond(s,e.status,"application/json",new JSONObject().put("error",e.getMessage()).toString().getBytes(StandardCharsets.UTF_8));}catch(Exception e){Log.e("DormPeer","Room request failed: "+path,e);respond(s,503,"application/json",new JSONObject().put("error","连接失败（"+e.getClass().getSimpleName()+"）。请检查创建者的小屋是否打开，或两机连接同一手机热点后重新复制邀请码").toString().getBytes(StandardCharsets.UTF_8));}
            }else if(method.equals("GET")){
                String file=path.equals("/")?"index.html":path.substring(1);if(!file.matches("[A-Za-z0-9._-]+")){respond(s,404,"text/plain",new byte[0]);return;}
                try(InputStream asset=context.getAssets().open(file)){respond(s,200,file.endsWith(".png")?"image/png":file.endsWith(".html")?"text/html; charset=utf-8":"application/octet-stream",read(asset,20000000));}catch(IOException e){respond(s,404,"text/plain",new byte[0]);}
            }else respond(s,405,"text/plain",new byte[0]);
        }catch(Exception ignored){}
    }
    private static void respond(Socket s,int code,String mime,byte[] body)throws IOException{OutputStream out=s.getOutputStream();String header="HTTP/1.1 "+code+" Result\r\nContent-Type: "+mime+"\r\nContent-Length: "+body.length+"\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";out.write(header.getBytes(StandardCharsets.UTF_8));out.write(body);out.flush();}
}
