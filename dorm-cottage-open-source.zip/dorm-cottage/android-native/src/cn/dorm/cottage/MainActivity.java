package cn.dorm.cottage;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;

/** Offline-capable Android entry point; all artwork and room logic ship inside APK. */
public final class MainActivity extends Activity {
    private WebView web;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final String home="http://127.0.0.1:"+PeerServer.HTTP_PORT+"/";
    private long lastBuzz;
    private boolean loaded=false;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        startForegroundService(new Intent(this,DormService.class));
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},100);
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.WHITE);root.setOnApplyWindowInsetsListener((view,insets)->{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});setContentView(root);
        web=new WebView(this);web.setBackgroundColor(Color.WHITE);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
        if(Build.VERSION.SDK_INT>=29)web.getSettings().setForceDark(WebSettings.FORCE_DARK_OFF);
        if(Build.VERSION.SDK_INT>=33)web.getSettings().setAlgorithmicDarkeningAllowed(false);
web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);web.addJavascriptInterface(new DeviceBridge(),"NativeDevice");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return !req.getUrl().toString().startsWith(home);}
            @Override public void onPageFinished(WebView view,String url){view.evaluateJavascript("document.body.classList.add('native-app');window.dormCloudMode=NativeDevice.isCloud();(()=>{if(!window.dormCloudMode)return;try{const s=JSON.parse(localStorage.getItem('cat-dorm-session')||'null');if(s&&(!s.token||!s.token.includes(':'))){localStorage.removeItem('cat-dorm-session');NativeDevice.clearSession();location.reload()}}catch(e){}})()",null);}
            @Override public void onReceivedError(WebView view,WebResourceRequest req,WebResourceError error){if(req.isForMainFrame())loaded=false;}
        });
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        Button network=new Button(this);network.setText("ⓘ");network.setTextSize(15);network.setBackgroundColor(Color.TRANSPARENT);network.setTextColor(Color.rgb(139,118,101));network.setContentDescription("查看小屋网络连接");FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(dp(40),dp(38),Gravity.TOP|Gravity.END);root.addView(network,p);network.setOnClickListener(v->showNetwork());
        waitForService(0);
    }
    private int dp(int value){return (int)(getResources().getDisplayMetrics().density*value+.5f);}
    private void waitForService(int attempt){
        if(isFinishing())return;DormService service=DormService.instance;
        if(service!=null&&service.peer!=null){loaded=true;web.loadUrl(home);service.setVisible(true);return;}
        if(attempt<50)handler.postDelayed(()->waitForService(attempt+1),100);
        else new AlertDialog.Builder(this).setTitle("小屋尚未启动").setMessage("手机内置服务未能启动，请重新打开应用。无需连接电脑。").setPositiveButton("重试",(d,w)->waitForService(0)).show();
    }
    private void showNetwork(){
        DormService service=DormService.instance;
        if(service!=null&&service.peer!=null&&!service.peer.isCloud()){
            new AlertDialog.Builder(this).setTitle("小屋局域网原型").setMessage("尚未配置自己的云端环境。当前使用手机本地服务，需同一可互通 Wi-Fi 或热点。校园网可能隔离设备。\n\n云端接入请按项目 README 配置 cloud-config.json 后重新构建。").setPositiveButton("知道啦",null).show();return;
        }
        new AlertDialog.Builder(this).setTitle("小屋云端同步").setMessage("宿舍状态和纸条保存在腾讯云上海免费环境。\n\n无需电脑开机，也无需手机处于同一 Wi-Fi。使用六位邀请码加入；旧版热点宿舍需重新创建。\n\n前台约每 15 秒刷新，后台约每分钟检查提醒。请允许通知和后台运行；系统省电、断网或强制停止仍可能中断提醒。\n\n当前版本 0.3.0 · 自动续费未开启，免费额度用尽可能暂停同步。").setPositiveButton("知道啦",null).setNeutralButton("后台运行设置",(d,w)->{try{startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}catch(Exception ignored){}}).setNegativeButton("重新加载",(d,w)->web.reload()).show();
    }
    public final class DeviceBridge {
        @JavascriptInterface public boolean isCloud(){DormService s=DormService.instance;return s!=null&&s.peer!=null&&s.peer.isCloud();}
        @JavascriptInterface public void vibrate(){runOnUiThread(()->{long now=SystemClock.elapsedRealtime();if(now-lastBuzz<1000)return;lastBuzz=now;Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);if(v!=null&&v.hasVibrator())v.vibrate(VibrationEffect.createOneShot(70,VibrationEffect.DEFAULT_AMPLITUDE));});}
        @JavascriptInterface public void saveSession(String token,String id,String room){DormService s=DormService.instance;if(s!=null)s.registerSession(token,id,room);}
        @JavascriptInterface public void clearSession(){DormService s=DormService.instance;if(s!=null)s.clearSession();}
        @JavascriptInterface public void ackState(long event,long note){DormService s=DormService.instance;if(s!=null)s.acknowledge(event,note);}
        @JavascriptInterface public void copyInvite(String room){String value=inviteCode(room);runOnUiThread(()->((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("宿舍邀请码",value)));}
        @JavascriptInterface public String inviteCode(String room){DormService s=DormService.instance;return s!=null&&s.peer!=null?s.peer.invite(room):room;}
    }
    @Override protected void onResume(){super.onResume();if(DormService.instance!=null)DormService.instance.setVisible(true);else if(web!=null&&loaded){startForegroundService(new Intent(this,DormService.class));waitForService(0);}if(web!=null&&loaded)web.onResume();}
    @Override protected void onPause(){if(DormService.instance!=null)DormService.instance.setVisible(false);if(web!=null)web.onPause();super.onPause();}
    @Override public void onBackPressed(){web.evaluateJavascript("(()=>{const d=document.querySelector('dialog[open]');if(d){d.close();return true;}return false;})()",result->{if(!"true".equals(result))moveTaskToBack(true);});}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);web.removeJavascriptInterface("NativeDevice");web.destroy();super.onDestroy();}
}
