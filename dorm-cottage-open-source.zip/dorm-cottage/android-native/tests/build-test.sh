#!/bin/sh
set -eu
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT}"
: "${JAVA_HOME:?Set JAVA_HOME}"
: "${DORM_BUILD_DIR:?Build the application first and set DORM_BUILD_DIR}"
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TEST_BUILD="$DORM_BUILD_DIR/test"
TOOLS="$ANDROID_SDK_ROOT/build-tools/35.0.1"
PLATFORM="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
mkdir -p "$TEST_BUILD/classes" "$TEST_BUILD/dex"
"$TOOLS/aapt2" link -o "$TEST_BUILD/base.apk" -I "$PLATFORM" --manifest "$ROOT/AndroidManifest.xml"
"$JAVA_HOME/bin/javac" -encoding UTF-8 -source 8 -target 8 -classpath "$PLATFORM:$DORM_BUILD_DIR/classes.jar" -d "$TEST_BUILD/classes" "$ROOT/NativeSmokeInstrumentation.java"
"$JAVA_HOME/bin/jar" cf "$TEST_BUILD/classes.jar" -C "$TEST_BUILD/classes" .
"$TOOLS/d8" --lib "$PLATFORM" --min-api 26 --output "$TEST_BUILD/dex" "$TEST_BUILD/classes.jar"
cp "$TEST_BUILD/base.apk" "$TEST_BUILD/unsigned.apk"
(cd "$TEST_BUILD/dex" && /usr/bin/zip -q -u "$TEST_BUILD/unsigned.apk" classes.dex)
"$TOOLS/zipalign" -f -p 4 "$TEST_BUILD/unsigned.apk" "$TEST_BUILD/aligned.apk"
"$TOOLS/apksigner" sign --ks "$DORM_BUILD_DIR/dorm-debug.jks" --ks-pass pass:android --key-pass pass:android --out "$TEST_BUILD/runtime-tests.apk" "$TEST_BUILD/aligned.apk"
echo "Runtime test APK: $TEST_BUILD/runtime-tests.apk"
echo 'Run on an Android device: adb shell am instrument -w cn.dorm.cottage.tests/cn.dorm.cottage.NativeSmokeInstrumentation'
