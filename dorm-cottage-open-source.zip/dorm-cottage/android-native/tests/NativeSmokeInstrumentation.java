package cn.dorm.cottage;
import android.app.*;
import android.content.*;
import android.os.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Runs on an Android runtime, not against desktop Android API stubs. */
public final class NativeSmokeInstrumentation extends Instrumentation {
    private int checks;
    private void check(boolean condition,String description){if(!condition)throw new AssertionError(description);checks++;}
    private JSONObject obj(String json)throws Exception{return new JSONObject(json);}
    @Override public void onCreate(Bundle arguments){super.onCreate(arguments);start();}
    @Override public void onStart(){Bundle result=new Bundle();try{
        Context c=getTargetContext();DormStore store=new DormStore(c);
        JSONObject a=store.api("create",obj("{\"name\":\"测试橘猫\",\"roomName\":\"手机内置测试屋\",\"slot\":2,\"appearance\":4}"),"");String room=a.getString("room"),at=a.getString("token"),aid=a.getString("id");
        check(a.getString("roomName").equals("手机内置测试屋"),"room name");check(a.getJSONArray("cats").getJSONObject(0).getInt("slot")==2,"selected bed");
        JSONObject b=store.api("join",new JSONObject().put("room",room).put("name","测试白猫").put("slot",0).put("appearance",4),"");String bt=b.getString("token");check(b.getJSONArray("cats").length()==2,"join another bed with same appearance");
        try{store.api("join",new JSONObject().put("room",room).put("name","冲突").put("slot",2),"");throw new AssertionError("occupied bed allowed");}catch(DormStore.Problem expected){checks++;}
        JSONObject sleep=store.api("update",new JSONObject().put("state","sleeping").put("reason","身体不舒服"),at);check(sleep.getJSONArray("events").length()==1,"sleep reminder event");
        check(store.api("update",new JSONObject().put("reason","想休息"),at).getJSONArray("events").length()==1,"no duplicate reminder");
        JSONObject awake=store.api("update",new JSONObject().put("state","awake").put("activity","reading").put("style","paws").put("bedding","mint").put("appearance",7),at);JSONObject mine=null;for(int i=0;i<awake.getJSONArray("cats").length();i++){JSONObject cat=awake.getJSONArray("cats").getJSONObject(i);if(cat.getString("id").equals(aid))mine=cat;}
        check(mine!=null&&mine.getString("activity").equals("reading"),"activity");check(mine.getInt("slot")==2&&mine.getInt("appearance")==7,"appearance does not move bed");check(mine.getString("style").equals("paws"),"sheet style");
        JSONObject notes=store.api("message",obj("{\"body\":\"早起告知测试纸条\",\"recipient\":\"all\"}"),at);long note=notes.getJSONArray("messages").getJSONObject(0).getLong("id");check(notes.getJSONArray("messages").length()==1,"post note");
        try{store.api("delete-message",new JSONObject().put("id",note),bt);throw new AssertionError("other author deletion allowed");}catch(DormStore.Problem expected){checks++;}
        check(store.api("delete-message",new JSONObject().put("id",note),at).getJSONArray("messages").length()==0,"delete own note");
        store.api("leave",new JSONObject(),bt);check(store.api("state",new JSONObject(),at).getJSONArray("cats").length()==1,"leave frees bed");
        try{store.api("state",new JSONObject(),bt);throw new AssertionError("left token still valid");}catch(DormStore.Problem expected){checks++;}
        // Verify the actual in-phone socket server and all assets without a PC server.
        PeerServer peer=new PeerServer(c);peer.start();
        URL url=new URL("http://127.0.0.1:18765/");String page=new String(PeerServer.read(url.openStream(),1000000),StandardCharsets.UTF_8);check(page.contains("宿舍小屋")&&page.contains("beginCreate"),"bundled page served offline");
        for(String file:new String[]{"room.png","day.png","closed.png","awake.png","activities.png","extra.png"}){URLConnection connection=new URL("http://127.0.0.1:18765/"+file).openConnection();check(PeerServer.read(connection.getInputStream(),20000000).length>1000,"asset "+file);}
        Thread.sleep(150);
        try(DatagramSocket socket=new DatagramSocket()){socket.setSoTimeout(2500);byte[] query=("DORM_ROOM_V1:"+room).getBytes(StandardCharsets.UTF_8);socket.send(new DatagramPacket(query,query.length,InetAddress.getByName("127.0.0.1"),18766));DatagramPacket answer=new DatagramPacket(new byte[256],256);socket.receive(answer);check(new String(answer.getData(),0,answer.getLength(),StandardCharsets.UTF_8).equals("DORM_FOUND_V1:"+room+":18765"),"UDP room discovery");}
        peer.stop();
        // Foreground service must be started from a visible app under Android's rules.
        if(Build.VERSION.SDK_INT>=33)getUiAutomation().grantRuntimePermission(c.getPackageName(),"android.permission.POST_NOTIFICATIONS");
        Intent start=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);Activity activity=startActivitySync(start);
        long deadline=System.currentTimeMillis()+6000;while(DormService.instance==null&&System.currentTimeMillis()<deadline)Thread.sleep(100);
        check(DormService.instance!=null&&DormService.instance.peer!=null,"phone foreground service started");
        runOnMainSync(activity::finish);
        c.stopService(new Intent(c,DormService.class));
        result.putString("stream","PASS: "+checks+" Android runtime checks\n");finish(Activity.RESULT_OK,result);
    }catch(Throwable e){StringWriter text=new StringWriter();e.printStackTrace(new PrintWriter(text));result.putString("stream","FAIL after "+checks+" checks: "+text);finish(Activity.RESULT_CANCELED,result);}}
}
