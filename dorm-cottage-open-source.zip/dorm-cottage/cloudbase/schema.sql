-- Atomic room API. Tables stay outside the public REST schema.
BEGIN;
CREATE SCHEMA IF NOT EXISTS dorm_private;
REVOKE ALL ON SCHEMA dorm_private FROM PUBLIC, anon, authenticated;
CREATE TABLE IF NOT EXISTS dorm_private.rooms(code text PRIMARY KEY, data jsonb NOT NULL);
REVOKE ALL ON dorm_private.rooms FROM PUBLIC, anon, authenticated;
CREATE OR REPLACE FUNCTION public.dorm_api(p_action text, p_data jsonb DEFAULT '{}'::jsonb, p_token text DEFAULT '')
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog AS $$
DECLARE
 r jsonb; cats jsonb; c jsonb; oldc jsonb; notes jsonb; events jsonb;
 v_code text; who text; secret text; n text; reason text; st text; act text;
 start_at text; bedding text; pattern text; note_body text; recipient text;
 slot_no integer; appearance integer; ix integer; i integer; changed boolean := false;
 now_s double precision := extract(epoch from clock_timestamp());
 day_start double precision := extract(epoch from (date_trunc('day',current_timestamp AT TIME ZONE 'Asia/Shanghai') AT TIME ZONE 'Asia/Shanghai'));
 next_id bigint; reply jsonb := '{}'::jsonb;
BEGIN
 IF p_action NOT IN ('create','preview','join','state','update','leave','message','delete-message') OR jsonb_typeof(p_data) <> 'object' OR octet_length(p_data::text)>8192 THEN RAISE EXCEPTION '请求格式无效'; END IF;
 IF p_action IN ('create','join','preview') THEN
  v_code := btrim(coalesce(p_data->>'room',''));
 ELSE
  IF p_token !~ '^[0-9]{6}:[a-f0-9]{64}$' THEN RAISE EXCEPTION '身份已失效，请重新进入云端宿舍'; END IF;
  v_code := split_part(p_token,':',1);
 END IF;
 IF p_action='create' THEN
  n := left(btrim(coalesce(p_data->>'roomName','')),24);
  IF n='' THEN RAISE EXCEPTION '请填写宿舍名称'; END IF;
  FOR i IN 1..20 LOOP
   v_code := (100000+floor(random()*900000)::integer)::text;
   r := jsonb_build_object('roomName',n,'cats','[]'::jsonb,'messages','[]'::jsonb,'events','[]'::jsonb,'sequence',0);
   INSERT INTO dorm_private.rooms VALUES(v_code,r) ON CONFLICT DO NOTHING;
   EXIT WHEN FOUND;
   IF i=20 THEN RAISE EXCEPTION '请稍后重试'; END IF;
  END LOOP;
 ELSE
  IF v_code !~ '^[0-9]{6}$' THEN RAISE EXCEPTION '请输入六位云端邀请码'; END IF;
  SELECT data INTO r FROM dorm_private.rooms WHERE rooms.code=v_code FOR UPDATE;
  IF r IS NULL THEN RAISE EXCEPTION '没有找到云端宿舍，请检查邀请码（旧版热点宿舍需重新创建）'; END IF;
 END IF;
 cats := r->'cats'; events := r->'events'; notes := r->'messages';
 IF p_action='preview' THEN RETURN jsonb_build_object('occupied',(SELECT coalesce(jsonb_agg(x->'slot'),'[]'::jsonb) FROM jsonb_array_elements(cats) x)); END IF;
 IF p_action IN ('create','join') THEN
  n := left(btrim(coalesce(p_data->>'name','')),16);
  slot_no := (p_data->>'slot')::integer; appearance := (p_data->>'appearance')::integer;
  IF n='' OR slot_no IS NULL OR slot_no NOT BETWEEN 0 AND 3 OR appearance IS NULL OR appearance NOT BETWEEN 0 AND 7 THEN RAISE EXCEPTION '请填写名字并选择床位、小猫'; END IF;
  IF EXISTS(SELECT 1 FROM jsonb_array_elements(cats) x WHERE (x->>'slot')::integer=slot_no) THEN RAISE EXCEPTION '这个床位已有人入住，请换一个'; END IF;
  who := replace(gen_random_uuid()::text,'-','');
  secret := v_code||':'||replace(gen_random_uuid()::text,'-','')||replace(gen_random_uuid()::text,'-','');
  c := jsonb_build_object('id',who,'token',secret,'slot',slot_no,'appearance',appearance,'name',n,'bedding','original','style','original','state','awake','activity','awake','reason','','start','','end','','updated',now_s);
  cats := cats||jsonb_build_array(c); changed := true;
  reply := jsonb_build_object('id',who,'token',secret);
 ELSE
  SELECT value,ordinality::integer-1 INTO c,ix FROM jsonb_array_elements(cats) WITH ORDINALITY WHERE value->>'token'=p_token;
  IF c IS NULL THEN RAISE EXCEPTION '身份已失效，请重新进入宿舍'; END IF;
  who := c->>'id';
 END IF;
 -- Start scheduled rests on server time; each transition creates exactly one event.
 FOR i IN 0..jsonb_array_length(cats)-1 LOOP
  oldc:=cats->i;
  IF oldc->>'state'='scheduled' AND (oldc->>'start')::timestamptz<=current_timestamp THEN
   oldc:=oldc||jsonb_build_object('state','sleeping','updated',now_s);
   cats:=jsonb_set(cats,ARRAY[i::text],oldc); changed:=true;
   next_id:=greatest(coalesce((r->>'sequence')::bigint,0)+1,floor(now_s*1000)::bigint); r:=r||jsonb_build_object('sequence',next_id);
   events:=events||jsonb_build_array(jsonb_build_object('id',next_id,'cat',oldc->>'id','name',oldc->>'name','reason',oldc->>'reason','created',now_s));
  END IF;
 END LOOP;
 IF p_action NOT IN ('create','join') THEN c:=cats->ix; END IF;
 IF p_action='leave' THEN
  cats:=cats-ix; UPDATE dorm_private.rooms SET data=r||jsonb_build_object('cats',cats,'events',events) WHERE rooms.code=v_code;
  RETURN jsonb_build_object('left',true);
 ELSIF p_action='update' THEN
  oldc:=c;
  n:=left(btrim(coalesce(p_data->>'name',c->>'name')),16); reason:=left(btrim(coalesce(p_data->>'reason',c->>'reason')),120);
  st:=coalesce(p_data->>'state',c->>'state'); act:=coalesce(p_data->>'activity',c->>'activity');
  appearance:=coalesce((p_data->>'appearance')::integer,(c->>'appearance')::integer);
  bedding:=coalesce(p_data->>'bedding',c->>'bedding'); pattern:=coalesce(p_data->>'style',c->>'style'); start_at:=coalesce(p_data->>'start',c->>'start');
  IF n='' OR st NOT IN ('awake','sleeping','scheduled') OR act NOT IN ('awake','study','music','reading','gaming','away') OR appearance NOT BETWEEN 0 AND 7 OR bedding NOT IN ('original','cream','peach','blue','mint','lavender') OR pattern NOT IN ('original','plain','gingham','stripes','stars','paws') THEN RAISE EXCEPTION '名字、状态或装扮无效'; END IF;
  IF st='scheduled' THEN
   IF start_at='' OR start_at !~ '(Z|[+-][0-9]{2}:[0-9]{2})$' OR start_at::timestamptz<=current_timestamp THEN RAISE EXCEPTION '预约时间需要晚于现在'; END IF;
  ELSIF st='awake' THEN start_at:=''; reason:='';
  ELSIF oldc->>'state'<>'sleeping' THEN start_at:=to_char(current_timestamp AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'); END IF;
  c:=c||jsonb_build_object('name',n,'reason',reason,'state',st,'activity',act,'appearance',appearance,'bedding',bedding,'style',pattern,'start',start_at,'end','','updated',now_s);
  cats:=jsonb_set(cats,ARRAY[ix::text],c); changed:=true;
  IF st='sleeping' AND oldc->>'state'<>'sleeping' THEN
   next_id:=greatest(coalesce((r->>'sequence')::bigint,0)+1,floor(now_s*1000)::bigint); r:=r||jsonb_build_object('sequence',next_id);
   events:=events||jsonb_build_array(jsonb_build_object('id',next_id,'cat',who,'name',n,'reason',reason,'created',now_s));
  END IF;
 ELSIF p_action='message' THEN
  note_body:=btrim(coalesce(p_data->>'body','')); recipient:=coalesce(p_data->>'recipient','all');
  IF length(note_body) NOT BETWEEN 1 AND 200 THEN RAISE EXCEPTION '留言需为 1—200 字'; END IF;
  IF recipient<>'all' AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(cats) x WHERE x->>'id'=recipient) THEN RAISE EXCEPTION '这位室友不在你的宿舍'; END IF;
  next_id:=greatest(coalesce((r->>'sequence')::bigint,0)+1,floor(now_s*1000)::bigint); r:=r||jsonb_build_object('sequence',next_id);
  notes:=notes||jsonb_build_array(jsonb_build_object('id',next_id,'sender',who,'recipient',recipient,'body',note_body,'created',now_s)); changed:=true;
 ELSIF p_action='delete-message' THEN
  IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(notes) x WHERE x->>'id'=p_data->>'id' AND x->>'sender'=who) THEN RAISE EXCEPTION '只能删除自己写的纸条'; END IF;
  SELECT coalesce(jsonb_agg(x),'[]'::jsonb) INTO notes FROM jsonb_array_elements(notes) x WHERE x->>'id'<>p_data->>'id'; changed:=true;
 END IF;
 SELECT coalesce(jsonb_agg(x ORDER BY (x->>'id')::bigint),'[]'::jsonb) INTO events FROM (SELECT value x FROM jsonb_array_elements(events) ORDER BY (value->>'id')::bigint DESC LIMIT 64) t;
 SELECT coalesce(jsonb_agg(x ORDER BY (x->>'id')::bigint DESC),'[]'::jsonb) INTO notes FROM (SELECT value x FROM jsonb_array_elements(notes) WHERE (value->>'created')::double precision>=day_start ORDER BY (value->>'id')::bigint DESC LIMIT 50) t;
 IF changed OR notes<>r->'messages' THEN UPDATE dorm_private.rooms SET data=r||jsonb_build_object('cats',cats,'messages',notes,'events',events) WHERE rooms.code=v_code; END IF;
 RETURN reply||jsonb_build_object('room',v_code,'roomName',r->>'roomName','serverTime',now_s,'cats',(SELECT coalesce(jsonb_agg(x-'token' ORDER BY (x->>'slot')::integer),'[]'::jsonb) FROM jsonb_array_elements(cats) x),'messages',notes,'events',events);
END;
$$;
REVOKE ALL ON FUNCTION public.dorm_api(text,jsonb,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.dorm_api(text,jsonb,text) TO anon, authenticated;
NOTIFY pgrst, 'reload schema';
COMMIT;
